package org.progx.dropinmotion.equation;

public interface Equation {
    public double compute(double variable);
}
