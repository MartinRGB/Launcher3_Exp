Mocos Controlator
=================

  Control the number of classes you skip using your android phone!
  Available free on play store (https://play.google.com/store/apps/details?id=com.marcioapf.mocos)
