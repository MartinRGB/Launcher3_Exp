package com.example.martinrgb.myapplication;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.NinePatch;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Interpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.Scroller;

import com.example.martinrgb.myapplication.transitioneffects.TransitionEffect;
import com.example.martinrgb.myapplication.transitioneffects.TransitionEffectSwitcher;


/**
 * The ScreenView is a wide area with a finite number of Screens. It supports scrolling and snapping
 * with intuitive animations.
 * @hide
 */
public class ScreenView extends ViewGroup {
    @SuppressWarnings("unused")
    private static final String TAG = "ScreenView";
    private static final int SNAP_DIRECTION_LEFT = -1;
    private static final int SNAP_DIRECTION_RIGHT = 1;
    protected static final int INVALID_SCREEN = -1;
    protected static final int INVALID_SIZE = -1;

    protected static final int INDICATOR_MEASURE_SPEC =
        MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED);

    protected static final int MINIMAL_SLIDE_BAR_POINT_WIDTH = 48;
    protected static final LinearLayout.LayoutParams SEEK_POINT_LAYOUT_PARAMS =
        new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, 1);

    private int mIndicatorCount;

//    private int mArrowLeftOnResId   = R.drawable.screen_view_arrow_left;
//    private int mArrowLeftOffResId  = R.drawable.screen_view_arrow_left_gray;
//    private int mArrowRightOnResId   = R.drawable.screen_view_arrow_right;
//    private int mArrowRightOffResId  = R.drawable.screen_view_arrow_right_gray;
//    private int mSeekPointResId = R.drawable.workspace_seekpoint;

    private int mArrowLeftOnResId   = R.drawable.screen_view_arrow_left;
    private int mArrowLeftOffResId  = R.drawable.screen_view_arrow_left_gray;
    private int mArrowRightOnResId   = R.drawable.screen_view_arrow_right;
    private int mArrowRightOffResId  = R.drawable.screen_view_arrow_right_gray;
    private int mSeekPointResId = R.drawable.workspace_seekpoint;

    private ArrowIndicator mArrowLeft;
    private ArrowIndicator mArrowRight;

    protected SeekBarIndicator mScreenSeekBar;
    protected SlideBar mSlideBar;
    protected boolean mIsSlideBarAutoHide;
    private static final int AUTO_HIDE_TIMEOUT_DURATION = 1000;
    private static final int AUTO_HIDE_ANIMATION_DURATION = 500;
    protected Runnable mAutoHideTimer = new Runnable() {
        public void run() {
            startHideSlideBar();
        }
    };

    public static final int SCREEN_ALIGN_CUSTOMIZED = 0;
    public static final int SCREEN_ALIGN_LEFT = 1;
    public static final int SCREEN_ALIGN_CENTER = 2;
    public static final int SCREEN_ALIGN_RIGHT = 3;

    public static final int SCREEN_LAYOUT_MODE_NORMAL = 0;
    public static final int SCREEN_LAYOUT_MODE_CENTER = 1;
    public static final int SCREEN_LAYOUT_MODE_PREVIEW = 2;
    public static final int SCREEN_LAYOUT_MODE_UNIFORM = 3;
    public static final int SCREEN_LAYOUT_MODE_MATRIX = 4;
    public static final int SCREEN_LAYOUT_MODE_GROUP = 5;
    public static final int SCREEN_LAYOUT_MODE_FIXED_GAP = 6;
    public static final int SCREEN_LAYOUT_MODE_CENTER_FIXED_GAP = 7;

    private final float PREVIEW_MODE_MAX_SCREEN_WIDTH = 0.20f;
    private int mScreenLayoutMode = SCREEN_LAYOUT_MODE_NORMAL;
    private boolean mLayoutScreensSeamless = false;
    private int mUniformLayoutModeMaxGap = Integer.MAX_VALUE;
    private int mUniformLayoutModeCurrentGap = mUniformLayoutModeMaxGap;

    private static final float GROUP_MODE_OVERLAY_RATIO = .2f;
    protected static final int GROUP_MODE_MAX_MEMBER_SIZE = 4;
    private static final int GROUP_MODE_DEFAULT_OFFSET_X = getDipPixelSize(8);
    private float mScreenDensity;
    private final Map<View, ArrayList<View>> mGroups = new HashMap<View, ArrayList<View>>();
    private View mCurrentUnfoldingHeader;
    private ArrayList<View> mCurrentUnfoldingList;
    private boolean mIsGroupUnfolding = false;
    private boolean mIsHidingHeader = false;
    private int mLastCurrentScreenBeforeUnfolding = -1;
    private int mGroupStartIndex = -1;
    private int mGroupEndIndex = -1;
    private int mLeftOffset = 0;
    private int mRightOccupiedCount = 0;
    private int mGroupModeVisualScreenSize = 0;
    private int mFixedGap = 0;
    private boolean mIgnoreCenterY = false;

    private int mScreenAlignment = SCREEN_ALIGN_LEFT;
    private int mScreenOffset = 0;
    private int mScrollOffset = 0;
    protected int mLastVisibleRange = -1;
    protected int mVisibleRange = -1;
    private int mChildScreenMeasureWidth = -1;
    private int mChildScreenMeasureHeight = -1;
    private int mChildScreenLayoutMeasureDiffX = 0;
    protected int mScreenContentWidth = 0;
    private int mScreenContentHeight = 0;

    private int mRowCountPerScreen = -1;
    private int mColumnCountPerScreen = -1;
    private int mRowGap = -1;
    private int mColumnGap = -1;

    private View mPreviewModeHeader = null;
    private View mPreviewModeFooter = null;

    protected int mCurrentScreen = INVALID_SCREEN;
    protected int mNextScreen = INVALID_SCREEN;
    protected int mScrollRightBound;
    protected int mScrollLeftBound;
    private int mScreenScrollLeftBound = 0;
    private int mScreenScrollRightBound = Integer.MAX_VALUE;
    private float mOverScrollRatio = 1f / 3;
    protected boolean mHasSuffixLinkedScreen = false;
    protected boolean mHasPrefixLinkedScreen = false;
    private boolean mScrollWholeScreen = false;
    protected Scroller mScroller;

    private int mScreenCounter = 0;

    private ScaleGestureDetector mScaleDetector;

    private float mLastMotionX;
    private float mLastMotionY;
    private float mSecondPointerStartX = INVALID_SIZE;
    private float mChildScaleX = 1;

    protected final static int TOUCH_STATE_REST         = 0;
    protected final static int TOUCH_STATE_SCROLLING    = 1;
    protected final static int TOUCH_STATE_SLIDING      = 3;
    protected final static int TOUCH_STATE_PINCHING     = 4;
    protected final static int TOUCH_STATE_CANCLED      = 5;
    public final static int MAX_TOUCH_STATE             = 5;
    private int mTouchState = TOUCH_STATE_REST;
    private boolean mTouchIntercepted;
    private boolean mCurrentGestureFinished;

    private final static float GESTURE_PUSH_CONFIRM_DIP = 50;
    private boolean mPushGestureEnabled = false;
    private int mScrollStartX = 0;
    private int mScrollingStateStartX = 0;
    protected boolean mGestureTrigged = false;

    protected OnClickListener mClickListener;
    protected OnLongClickListener mLongClickListener;
    private boolean mAllowLongPress = true;

    //define touch slop becasuse the system VIEW_CONFIGURATION_TOUCH_SLOP is changed to smaller
    private static final int VIEW_CONFIGURATION_TOUCH_SLOP = getDipPixelSize(5);
    private int mTouchSlop;
    private int mSnapDelta;

    /**
     * The velocity at which a fling gesture will cause us to snap to the next screen
     */
    protected static final int SNAP_VELOCITY = 300;
    private int mMaximumVelocity;


    private static final int INVALID_POINTER = -1;
    protected int mActivePointerId = INVALID_POINTER;

    private static final float NANOTIME_DIV = 1000000000.0f;
    private static final float SMOOTHING_SPEED = 0.75f;
    private static final float SMOOTHING_CONSTANT = (float) (0.016 / Math.log(SMOOTHING_SPEED));
    private float mSmoothingTime;
    private float mTouchX;
    private float mConfirmHorizontalScrollRatio = 0.5f;

    private ScreenViewOvershootInterpolator mScreenViewOvershootInterpolator;
    private ScrollerInterpolator mScrollerInterpolator = new ScrollerInterpolator();


    private static final float BASELINE_FLING_VELOCITY = 2500.f;
    private static final float FLING_VELOCITY_INFLUENCE = 0.4f;

    protected TransitionEffectSwitcher mTransitionEffect = new TransitionEffectSwitcher();
    protected int mLastScrollX = 0;
    private float mOvershootTension = TransitionEffect.DEFAULT_OVER_SHOOT_TENSION;
    private int mScreenSnapDuration = TransitionEffect.DEFAULT_SCREEN_SNAP_DURATION;

    private boolean mEnableReverseDrawingMode = false;

    public void setFixedGap(int gap) {
        mFixedGap = gap;
    }

    public void ignoreCenterY(boolean ignore) {
        mIgnoreCenterY = ignore;
    }

    public void setOvershootTension(float tension) {
        mOvershootTension = tension;
        if(mScreenViewOvershootInterpolator != null) {
            mScreenViewOvershootInterpolator.mTension = tension;
        }
    }

    public void setTouchSlop(int slop) {
        mTouchSlop = slop;
    }

    public void setConfirmHorizontalScrollRatio(float ratio) {
        mConfirmHorizontalScrollRatio = ratio;
    }

    private int mScrollX;

    public void setScreenSnapDuration(int duration) {
        mScreenSnapDuration = duration;
    }

    public int getScreenSnapMaxDuration() {
        return (int) (mScreenSnapDuration * 1.5f);
    }

    public void setMaximumSnapVelocity(int velocity) {
        mMaximumVelocity = velocity;
    }

    public void setScrollWholeScreen(boolean wholeScreen) {
        mScrollWholeScreen = wholeScreen;
    }

    public void setScreenScrollRange(int leftIndex, int rightIndex) {
        if (mScreenLayoutMode != SCREEN_LAYOUT_MODE_GROUP) {
            mScreenScrollLeftBound = leftIndex;
            mScreenScrollRightBound = rightIndex;
            refreshScrollBound();
            correctCurrentScreen(true);
        }
    }

    public void resetScreenScrollRange() {
        mScreenScrollLeftBound = 0;
        mScreenScrollRightBound = Integer.MAX_VALUE;
        refreshScrollBound();
        correctCurrentScreen(true);
    }

    public void setPushGestureEnabled(boolean pushGesture) {
        mPushGestureEnabled = pushGesture;
    }

    public class GestureVelocityTracker {
        private VelocityTracker mVelocityTracker;
        private class Tracker {
            float start;
            float fold;
            float prev;
            public Tracker() {
                reset();
            }
            public void reset() {
                start = fold = prev = -1;
            }
        }
        private Tracker mTx = new Tracker();
        private Tracker mTy = new Tracker();
        private int mPointerId = -1;
        private int mCounter = -1;
        private final static float mMinFoldDist = 3.0f;
        private final int DEFAULT_VERTICAL_GESTURE_CONFIRM_DIST =
                Math.round(50.f * Resources.getSystem().getDisplayMetrics().density);
        private boolean mVerticalGestureConfirmed;

        public final static int FLING_NONE = 0;
        public final static int FLING_LEFT = 1;
        public final static int FLING_RIGHT = 2;
        public final static int FLING_CANCEL = 3;
        public final static int FLING_ALIGN = 4;
        public final static int FLING_UP = 10;
        public final static int FLING_DOWN = 11;
        public void recycle() {
            if (mVelocityTracker != null) {
                mVelocityTracker.recycle();
                mVelocityTracker = null;
            }
            reset();
        }

        public void addMovement(MotionEvent ev) {
            int action = (ev.getAction() & MotionEvent.ACTION_MASK);
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                return;
            }
            mCounter++;
            if (mVelocityTracker == null) {
                mVelocityTracker = VelocityTracker.obtain();
            }
            mVelocityTracker.addMovement(ev);
            float curX = ev.getX();
            float curY = ev.getY();
            if (mPointerId != -1) {
                final int pIndex = ev.findPointerIndex(mPointerId);
                if (pIndex != -1) {
                    curX = ev.getX(pIndex);
                    curY = ev.getY(pIndex);
                } else {
                    mPointerId = -1;
                }
            }
            trackPoint(curX, mTx);
            trackPoint(curY, mTy);
        }
        private void trackPoint (float p, Tracker t) {
            if (t.start < 0) {
                t.start = p;
                return;
            }
            if (t.prev < 0) {
                t.prev = p;
                return;
            }
            if (t.fold < 0) {
                if ((t.prev > t.start && p < t.prev) || (t.prev < t.start && p > t.prev)) {
                    if (Math.abs(p - t.start) > mMinFoldDist) {
                        t.fold = t.prev;
                    }
                }
            } else {
                if (t.fold != t.prev) {
                    if ((t.prev > t.fold && p < t.prev) || (t.prev < t.fold && p > t.prev)) {
                        if (Math.abs(p - t.fold) > mMinFoldDist) {
                            t.start = t.fold;
                            t.fold = t.prev;
                        }
                    }
                }
            }
            t.prev = p;
        }
        private void reset() {
            mTx.reset();
            mTy.reset();
            mPointerId = -1;
            mCounter = 0;
            mVerticalGestureConfirmed = false;
        }
        public void init(int pointerId) {
            if (mVelocityTracker == null) {
                mVelocityTracker = VelocityTracker.obtain();
            } else {
                mVelocityTracker.clear();
            }
            reset();
            mPointerId = pointerId;
        }
        public int getCounter() {
            return mCounter;
        }
        public float getXVelocity(int units, int maxVelocity, int pointerId) {
            if (mVelocityTracker == null) {
                return mMaximumVelocity;
            }
            mVelocityTracker.computeCurrentVelocity(units, maxVelocity);
            return mVelocityTracker.getXVelocity(pointerId);
        }
        public float getYVelocity(int units, int maxVelocity, int pointerId) {
            if (mVelocityTracker == null) {
                return mMaximumVelocity;
            }
            mVelocityTracker.computeCurrentVelocity(units, maxVelocity);
            return mVelocityTracker.getYVelocity(pointerId);
        }
        public int getVerticalGesture() {
            if (mVerticalGestureConfirmed || getCounter() < 5) {
                return FLING_NONE;
            }
            float v = getYVelocity(1000, mMaximumVelocity, 0);
            if (Math.abs(v) >= mMaximumVelocity / 3 &&
                    Math.abs(mTy.start - mTy.prev) > DEFAULT_VERTICAL_GESTURE_CONFIRM_DIST) {
                mVerticalGestureConfirmed = true;
                return mTy.start > mTy.prev ? FLING_UP : FLING_DOWN;
            }
            return FLING_NONE;
        }
        public int getXFlingDirection(float velocity) {
            return getFlingDirection(mTx, velocity);
        }
        public int getFlingDirection(Tracker t, float velocity) {
            if (velocity > SNAP_VELOCITY) {
                if (t.fold < 0) {
                    return t.prev > t.start ? FLING_LEFT : FLING_RIGHT;
                }
                if (t.prev < t.fold) {
                    if (mScrollX < getCurrentScreen().getLeft()) {
                        return FLING_CANCEL;
                    }
                    return FLING_RIGHT;
                }
                if (t.prev > t.fold) {
                    if (mScrollX > getCurrentScreen().getLeft()) {
                        return FLING_CANCEL;
                    }
                    return FLING_LEFT;
                }
                return FLING_CANCEL;
            }
            return FLING_ALIGN;
        }
    }

    GestureVelocityTracker mGestureVelocityTracker = new GestureVelocityTracker();

    private class ScreenViewOvershootInterpolator implements Interpolator {
        private float mTension;

        public ScreenViewOvershootInterpolator() {
            mTension = mOvershootTension;
        }

        public void setDistance(int distance, int velocity) {
            mTension = distance > 0
                    ? mOvershootTension / distance
                    : mOvershootTension;
        }

        public void disableSettle() {
            mTension = 0.f;
        }

        public float getInterpolation(float t) {
            t -= 1f;
            return t * t * ((mTension + 1) * t + mTension) + 1f;
        }
    }

    private class ScrollerInterpolator implements Interpolator {

        private android.animation.TimeInterpolator mDelegateInterpolator;

        public void setDelegateInterpolator(android.animation.TimeInterpolator delegateInterpolator) {
            mDelegateInterpolator = delegateInterpolator;
        }

        @Override
        public float getInterpolation(float input) {
            if (mDelegateInterpolator != null) {
                return mDelegateInterpolator.getInterpolation(input);
            }
            return getDefaultScrollInterpolator().getInterpolation(input);
        }
    }

    public void setScrollerInterpolator(android.animation.TimeInterpolator interpolator) {
        mScrollerInterpolator.setDelegateInterpolator(interpolator);
    }

    /**
     * Used to create the ScreenView from code.
     *
     * @param context The application's context.
     */
    private Context mContext;
    public ScreenView(Context context) {
        super(context);
        initScreenView(context);
    }

    /**
     * Used to inflate the ScreenView from XML.
     *
     * @param context The application's context.
     * @param attrs The attribtues set containing the ScreenView's customization values.
     */
    public ScreenView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    /**
     * Used to inflate the ScreenView from XML.
     *
     * @param context The application's context.
     * @param attrs The attribtues set containing the ScreenView's customization values.
     * @param defStyle Unused.
     */
    public ScreenView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        initScreenView(context);
    }

    /**
     * Initializes various states for this ScreenView.
     */
    private void initScreenView(Context context) {
        setAlwaysDrawnWithCacheEnabled(true);
        mScreenViewOvershootInterpolator = new ScreenViewOvershootInterpolator();
        mScroller = new Scroller(context, mScrollerInterpolator);

        final ViewConfiguration configuration = ViewConfiguration.get(context);
        mTouchSlop = VIEW_CONFIGURATION_TOUCH_SLOP;
        setMaximumSnapVelocity(configuration.getScaledMaximumFlingVelocity());

        mScaleDetector = new ScaleGestureDetector(context, new ScaleDetectorListener());

        Display display = ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
        DisplayMetrics dm = new DisplayMetrics();
        display.getMetrics(dm);
        mScreenDensity = dm.density;
    }

    protected Interpolator getDefaultScrollInterpolator() {
        return mScreenViewOvershootInterpolator;
    }

    /**
     * This method is used to specify arrow indicators' position.
     * @param margin Top margin is for both two arrows, Left/Right margin is for left/right arrow.
     *               passing a null margin meaning disabling arrow indicators
     */
    public void setArrowIndicatorMarginRect(Rect margin) {
        if (margin != null) {
            FrameLayout.LayoutParams leftArrowLayout;
            FrameLayout.LayoutParams rightArrowLayout;

            if (mArrowLeft == null) {
                leftArrowLayout = new FrameLayout.LayoutParams(
                        LayoutParams.WRAP_CONTENT,
                        LayoutParams.WRAP_CONTENT,
                        Gravity.LEFT | Gravity.CENTER_VERTICAL);
                mArrowLeft = new ArrowIndicator(mContext);
                mArrowLeft.setImageResource(mArrowLeftOnResId);
                addIndicator(mArrowLeft, leftArrowLayout);

                rightArrowLayout = new FrameLayout.LayoutParams(
                        LayoutParams.WRAP_CONTENT,
                        LayoutParams.WRAP_CONTENT,
                        Gravity.RIGHT | Gravity.CENTER_VERTICAL);
                mArrowRight = new ArrowIndicator(mContext);
                mArrowRight.setImageResource(mArrowRightOnResId);
                addIndicator(mArrowRight, rightArrowLayout);
            }
            else {
                leftArrowLayout = (FrameLayout.LayoutParams) mArrowLeft.getLayoutParams();
                rightArrowLayout = (FrameLayout.LayoutParams) mArrowRight.getLayoutParams();
            }

            leftArrowLayout.setMargins(margin.left, margin.top, 0, margin.bottom);
            rightArrowLayout.setMargins(0, margin.top, margin.right, margin.bottom);
        }
        else if (mArrowLeft != null) {
            removeIndicator(mArrowLeft);
            removeIndicator(mArrowRight);
            mArrowLeft = null;
            mArrowRight = null;
        }
    }

    /**
     * This method is used to replace default resource for arrows. Currently this method should
     * be called before calling setArrowIndicatorMarginRect() during initial phase.
     */
    public void setArrowIndicatorResource(int leftOn, int leftOff, int rightOn, int rightOff) {
        mArrowLeftOnResId = leftOn;
        mArrowLeftOffResId = leftOff;
        mArrowRightOnResId = rightOn;
        mArrowRightOffResId = rightOff;
    }

    /**
     * This method is used to replace default resource for seek point. Currently this method should
     * be called before calling addView().
     */
    public void setSeekPointResource(int seekPointResId) {
        if (mSeekPointResId != seekPointResId) {
            mSeekPointResId = seekPointResId;
            if (mScreenSeekBar != null) {
                int count = getScreenCount();
                for (int i = 0; i < count; i++) {
                    final ImageView v = (ImageView) mScreenSeekBar.getChildAt(i);
                    if (v != null) {
                        v.setImageResource(mSeekPointResId);
                        v.getDrawable().jumpToCurrentState();
                    }
                }
            }
        }
    }

    /**
     * This method is used to specify screen seek bar's position.
     * @param params The layout parameters to be used when adding seekbar into the screen view
     */
    public void setSeekBarPosition(FrameLayout.LayoutParams params) {
        if (params != null) {
            if (mScreenSeekBar == null) {
                mScreenSeekBar = new SeekBarIndicator(mContext);
                mScreenSeekBar.setGravity(Gravity.CENTER_VERTICAL);
                mScreenSeekBar.setAnimationCacheEnabled(false);
                addIndicator(mScreenSeekBar, params);
            } else {
                mScreenSeekBar.setLayoutParams(params);
            }
        }
        else if (mScreenSeekBar != null) {
            removeIndicator(mScreenSeekBar);
            mScreenSeekBar = null;
        }
    }

    private interface Indicator {
        boolean fastOffset(int offset);
    }

    protected class ArrowIndicator extends ImageView implements Indicator {

        public ArrowIndicator(Context context) {
            super(context);
        }

        @Override
        public boolean fastOffset(int offset) {
//            if (mLeft != offset) {
//                mRight = offset + mRight - mLeft;
//                mLeft = offset;
//                return true;
//            }
//            return false;
        }
    }

    protected class SeekBarIndicator extends LinearLayout implements Indicator {

        public SeekBarIndicator(Context context) {
            super(context);
        }

        @Override
        public boolean fastOffset(int offset) {
//            if (mLeft != offset) {
//                mRight = offset + mRight - mLeft;
//                mLeft = offset;
//                return true;
//            }
//            return false;
          }
    }

    protected class SlideBar extends FrameLayout implements Indicator{
        private Bitmap mSlidePointBmp;
        private NinePatch mSlidePoint;
        private Rect mPos = new Rect();
        private Rect mPadding = new Rect();

        public SlideBar(Context context, int slideDrawableId, int backgroundDrawableId) {
            super(context);
            mSlidePointBmp = BitmapFactory.decodeResource(getResources(), slideDrawableId);
            if(mSlidePointBmp == null) {
                return;
            }

            byte npChunk[] = mSlidePointBmp.getNinePatchChunk();
            if(npChunk != null) {
                mSlidePoint = new NinePatch(mSlidePointBmp, npChunk, null);
            } else {
                return;
            }
            FrameLayout background = new FrameLayout(mContext);
            background.setBackgroundResource(backgroundDrawableId);
            FrameLayout.LayoutParams backgroundParams = new FrameLayout.LayoutParams(
                    LayoutParams.MATCH_PARENT,
                    LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM);
            addView(background, backgroundParams);
            mPadding.left = background.getPaddingLeft();
            mPadding.top = background.getPaddingTop();
            mPadding.right = background.getPaddingRight();
            mPadding.bottom = background.getPaddingBottom();
            mPos.top = mPadding.top;
            mPos.bottom = mPos.top + mSlidePointBmp.getHeight();
        }

        @Override
        protected int getSuggestedMinimumHeight() {
            return Math.max(mSlidePointBmp.getHeight(), super.getSuggestedMinimumHeight());
        }

        @Override
        protected void dispatchDraw(Canvas canvas) {
            super.dispatchDraw(canvas);
            if(mSlidePoint != null) {
                mSlidePoint.draw(canvas, mPos);
            }
        }

        @Override
        protected boolean setFrame(int left, int top, int right, int bottom) {
            final boolean r = super.setFrame(left, top, right, bottom);
            if(mSlidePoint != null) {
                mPos.bottom = bottom - top - mPadding.bottom;
                mPos.top = mPos.bottom - mSlidePoint.getHeight();
            }
            return r;
        }

        public void setPosition(int left, int right) {
            mPos.left = left;
            mPos.right = right;
        }

        public int getSlideWidth() {
            return getMeasuredWidth() - mPadding.left - mPadding.right;
        }

        public int getSlidePaddingLeft() {
            return mPadding.left;
        }
        @Override
        public boolean fastOffset(int offset) {
//            if (mLeft != offset) {
//                mRight = offset + mRight - mLeft;
//                mLeft = offset;
//                return true;
//            }
//            return false;
        }
    }

    /**
     * This method is used to specify screen slide bar's position.
     * @param params The layout parameters to be used when adding slide bar into the screen view
     */
    public void setSlideBarPosition(FrameLayout.LayoutParams params) {
//        setSlideBarPosition(params, R.drawable.screen_view_slide_bar, R.drawable.screen_view_slide_bar_bg, false);
    }

    /**
     * This method is used to specify screen slide bar's position.
     * @param params The layout parameters to be used when adding slide bar into the screen view
     */
    public void setSlideBarPosition(FrameLayout.LayoutParams params, int slideDrawableId, int backgroundDrawableId, boolean isAutoHide) {
        mIsSlideBarAutoHide = isAutoHide;
        if (params != null) {
            if (mSlideBar == null) {
                mSlideBar = new SlideBar(mContext, slideDrawableId, backgroundDrawableId);
                mSlideBar.setOnTouchListener(new SliderTouchListener());
                mSlideBar.setAnimationCacheEnabled(false);
                addIndicator(mSlideBar, params);
            } else {
                mSlideBar.setLayoutParams(params);
            }
        }
        else if (mSlideBar != null) {
            removeIndicator(mSlideBar);
            mSlideBar = null;
        }
    }

    private void showSlideBar() {
        if (mSlideBar == null || !mIsSlideBarAutoHide) {
            return;
        }

        removeCallbacks(mAutoHideTimer);
        mSlideBar.animate().cancel();

        mSlideBar.setAlpha(1f);
        mSlideBar.setVisibility(VISIBLE);

        if (mTouchState == TOUCH_STATE_REST) {
            postDelayed(mAutoHideTimer, AUTO_HIDE_TIMEOUT_DURATION);
        }
    }

    private void startHideSlideBar() {
        if (!mIsSlideBarAutoHide) {
            return;
        }
        mSlideBar.animate()
                .setDuration(AUTO_HIDE_ANIMATION_DURATION)
                .alpha(0f)
                .setListener(new AnimatorListenerAdapter() {
                    public void onAnimationEnd(Animator animation) {
                        mSlideBar.setVisibility(INVISIBLE);
                    }
                    public void onAnimationCancel(Animator animation) {
                        mSlideBar.setVisibility(INVISIBLE);
                        mSlideBar.setAlpha(1.f);
                    }
                });
    }

    public void forceEndSlideBarHideAnim() {
        if (mSlideBar != null) {
            mSlideBar.animate().cancel();
        }
    }

    public void setIndicatorBarVisibility(int visibility) {
        setSeekBarVisibility(visibility);
        setSlideBarVisibility(visibility);
    }

    public void setSeekBarVisibility(int visibility) {
        if (mScreenSeekBar == null) {
            return;
        }
        mScreenSeekBar.setVisibility(visibility);
    }

    public void setSlideBarVisibility(int visibility) {
        if (mSlideBar == null) {
            return;
        }
        mSlideBar.setVisibility(visibility);
    }

    public void setLayoutScreenSeamless(boolean isSeamless) {
        mLayoutScreensSeamless = isSeamless;
        requestLayout();
    }

    public void setScreenLayoutMode(int mode) {
        if (mScreenLayoutMode != mode) {
            if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_UNIFORM) {
                mUniformLayoutModeMaxGap = Integer.MAX_VALUE;
            }
            mScreenLayoutMode = mode;
            requestLayout();
        }
    }

    public interface GroupModeItem {
        void onFolding();
        void onUnFolding();
    }

    protected void onUnfoldGroup(final View header,
            final ArrayList<View> members, boolean showAnim) {
        for (View v : members) {
            if (showAnim && v instanceof ScreenView.GroupModeItem) {
                ((GroupModeItem) v).onUnFolding();
            }
        }
    }

    protected void onFoldGroup(final View header,
            final ArrayList<View> members, boolean showAnim) {
        for (View v : members) {
            if (showAnim && v instanceof ScreenView.GroupModeItem) {
                ((GroupModeItem) v).onFolding();
            }
        }
    }

    protected void foldingGroupMembers() {
        if (!mIsGroupUnfolding)
            return;
        mGroups.put(mCurrentUnfoldingHeader, mCurrentUnfoldingList);
        mGroupModeVisualScreenSize = INVALID_SIZE;
        onFoldGroup(mCurrentUnfoldingHeader, mCurrentUnfoldingList, true);
        mIsGroupUnfolding = false;
        mIsHidingHeader = false;
        mGroupStartIndex = -1;
        mGroupEndIndex = -1;
        mLeftOffset = 0;
        mRightOccupiedCount = 0;
        mCurrentScreen = mLastCurrentScreenBeforeUnfolding;
        refreshScrollBound();
        requestLayout();
        snapToScreen(mCurrentScreen);
    }

    private void reComputeGroupParams() {
        if (mLastVisibleRange == mVisibleRange) return;

        mIsGroupUnfolding = false;
        int visualIndex = getVisualIndexInGroupMode(mGroupStartIndex);
        int groupSize = mCurrentUnfoldingList.size() + (mIsHidingHeader ? 0 : 1);
        mRightOccupiedCount = groupSize % mVisibleRange == 0 ? 0
                : mVisibleRange - groupSize % mVisibleRange;
        mLeftOffset = visualIndex % mVisibleRange;
        mIsGroupUnfolding = true;
    }

    protected boolean unfoldingGroupMembers(View header, boolean hideHeader) {
        if (mScreenLayoutMode != SCREEN_LAYOUT_MODE_GROUP || mIsGroupUnfolding
                || header == null || !mGroups.containsKey(header)) {
            return false;
        }
        mCurrentUnfoldingHeader = header;
        mCurrentUnfoldingList = mGroups.get(header);
        onUnfoldGroup(mCurrentUnfoldingHeader, mCurrentUnfoldingList, true);
        mGroupModeVisualScreenSize = INVALID_SIZE;
        int groupStartIndex = indexOfChild(header) + (hideHeader ? 1 : 0);
        int groupSize = mCurrentUnfoldingList.size() + (hideHeader ? 0 : 1);
        int visualIndex = getVisualIndexInGroupMode(groupStartIndex);

        //move other children out of current Screen
        mRightOccupiedCount = groupSize % mVisibleRange == 0 ? 0
                : mVisibleRange - groupSize % mVisibleRange;
        mLeftOffset = visualIndex % mVisibleRange;

        if(DeviceConfig.isLayoutRtl()) {
            mRightOccupiedCount = mVisibleRange;
            mLeftOffset = groupSize > mVisibleRange ? groupSize : mVisibleRange;
        }

        if (mLayoutScreensSeamless && getVisualIndexInGroupMode(groupStartIndex)
                - getVisualIndexInGroupMode(mCurrentScreen) >= mVisibleRange) {
            mLeftOffset += mVisibleRange;
        }
        mGroupStartIndex = groupStartIndex;
        mGroupEndIndex = groupStartIndex + groupSize - 1;

        mGroups.remove(header);
        mIsGroupUnfolding = true;
        mIsHidingHeader = hideHeader;
        mLastCurrentScreenBeforeUnfolding = mCurrentScreen;
        mCurrentScreen = groupStartIndex;
        refreshScrollBound();
        snapToScreen(mGroupStartIndex);
        requestLayout();
        return true;
    }

    protected void insertGroups(Map<View, ArrayList<View>> groups) {
        mGroups.clear();
        for(View v : groups.keySet()) {
            ArrayList<View> members = groups.get(v);
            if (members.size() > 0) {
                mGroups.put(v, members);
            }
        }
        mGroupModeVisualScreenSize = INVALID_SIZE;
    }

    protected boolean isGroupHeader(View v) {
        if (v == null)    return false;
        if (mGroups.containsKey(v)) {
            return true;
        }
        return false;
    }

    protected boolean hasGroupUnfolding() {
        return mIsGroupUnfolding;
    }

    protected int getScreenIndexByPoint(int x, int y) {
        //get the childIndex in the current screen.
        int index = -1;
        int wholeScreenIndex = x / getWidth();

        if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_MATRIX ||
                mScreenLayoutMode == SCREEN_LAYOUT_MODE_GROUP) {
            int columnIndex = (x - mPaddingLeft) % getWidth() / mChildScreenMeasureWidth;
            int rowIndex = (y - mPaddingTop) / mChildScreenMeasureHeight;
            index = wholeScreenIndex * mVisibleRange + mColumnCountPerScreen * rowIndex + columnIndex;
        } else {
            index = wholeScreenIndex * mVisibleRange + (x - mPaddingLeft) % getWidth() / mChildScreenMeasureWidth;
            if (DeviceConfig.isLayoutRtl()) {
                index = getScreenCount() - index - 1;
            }
        }

        return Math.min(index, getScreenCount()-1);
    }

    private int getGroupBounderIndex(int direction, int currentIndex) {
        View curScreen = getScreen(currentIndex);
        if (direction == SNAP_DIRECTION_LEFT) {
            for (View key : mGroups.keySet()) {
                if (mGroups.get(key).contains(curScreen)) {
                    return indexOfChild(key);
                }
            }
            return currentIndex;
        } else {
            if (mGroups.containsKey(curScreen)) {
                return currentIndex + mGroups.get(curScreen).size();
            } else {
                return currentIndex;
            }
        }
    }

    private int calibrateCurrentScreenIndex(int currentScreen) {
        int screenIndex = Math.max(0, Math.min(currentScreen, getScreenCount() - 1));
        int visualIndex = screenIndex;
        if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_GROUP) {
            visualIndex = getVisualIndexInGroupMode(screenIndex);
        }
        if (visualIndex % mVisibleRange != 0) {
            int steps;
            if (DeviceConfig.isLayoutRtl()) {
                 steps = mVisibleRange - visualIndex % mVisibleRange - 1;
            } else {
                steps = visualIndex % mVisibleRange;
            }
            screenIndex = getSnapToScreenIndex(screenIndex, steps, DeviceConfig.isLayoutRtl() ? 1 : -1);
        } else if (DeviceConfig.isLayoutRtl() &&
                mScreenLayoutMode == SCREEN_LAYOUT_MODE_FIXED_GAP && visualIndex == 0) {
            screenIndex = mVisibleRange - 1;
        }
        return screenIndex;
    }

    private int getSnapToScreenIndex(int currentIndex, int steps, int direction) {
        int resultIndex = currentIndex;
        if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_GROUP) {
            int bounderIndex = getGroupBounderIndex(direction, currentIndex);
            resultIndex = bounderIndex;
            int skipCount = 0;
            int nextIndex = currentIndex;
            for (int i = 1; i < steps; i ++) {
                int oldIndex = nextIndex;
                nextIndex = bounderIndex + direction *(i + skipCount);
                if (nextIndex >= mScreenCounter || nextIndex < 0) {
                    if (DeviceConfig.isLayoutRtl()) {
                        return oldIndex;
                    }
                    return currentIndex;
                }
                View nextScreen = getScreen(nextIndex);
                if (direction == -1) {
                    for (ArrayList<View> group : mGroups.values()) {
                        if (group.contains(nextScreen)) {
                            skipCount += group.indexOf(nextScreen) + 1;
                        }
                    }
                }else {
                    if (mGroups.containsKey(nextScreen)) {
                        skipCount += mGroups.get(nextScreen).size();
                    }
                }
            }
            resultIndex += direction * (steps + skipCount);
        }else {
            resultIndex += direction * steps;
        }
        return Math.max(0, Math.min(resultIndex, getScreenCount() - 1));
    }

    private int getScreenActualIndexInGroupMode(int visualScreenIndex) {
        int finalIndex = visualScreenIndex;
        if (mIsGroupUnfolding) {
            finalIndex += mLeftOffset;
            if (visualScreenIndex > mGroupEndIndex) {
                finalIndex -= mRightOccupiedCount;
            }
        }
        for (int i = 0; i < finalIndex; i ++) {
            View screen = getScreen(i);
            if (mGroups.containsKey(screen)) {
                finalIndex += mGroups.get(screen).size();
            }
        }
        return finalIndex;
    }

    private int getGroupModeVisualScreenSize() {
        if (mGroupModeVisualScreenSize == INVALID_SIZE) {
            mGroupModeVisualScreenSize = mScreenCounter;
            for (View header : mGroups.keySet()) {
                mGroupModeVisualScreenSize -= mGroups.get(header).size();
            }
        }
        return mGroupModeVisualScreenSize;
    }

    private int getVisualIndexInGroupMode(int screenIndex) {
        int finalIndex = screenIndex;
        View targetScreen = getScreen(screenIndex);
        for (int i = 0; i < screenIndex; i++) {
            View screen = getScreen(i);
            if (mGroups.containsKey(screen)) {
                ArrayList<View> members = mGroups.get(screen);
                if (members.contains(targetScreen)) {
                    finalIndex -= members.indexOf(targetScreen) + 1;
                    break;
                } else {
                    finalIndex -= members.size();
                }
            }
        }
        if (mIsGroupUnfolding) {
            if (DeviceConfig.isLayoutRtl()) {
                if (screenIndex < mGroupStartIndex) {
                    finalIndex -= mRightOccupiedCount;
                }
                finalIndex += mLeftOffset;
            } else {
                if (screenIndex > mGroupEndIndex) {
                    finalIndex += mRightOccupiedCount;
                }
                finalIndex -= mLeftOffset;
            }
        }
        return finalIndex;
    }

    public int getScreenLayoutMode() {
        return mScreenLayoutMode;
    }

    public void setPreviewModeHeader(View header) {
        mPreviewModeHeader = header;
        requestLayout();
    }

    public void setPreviewModeFooter(View footer) {
        mPreviewModeFooter = footer;
        requestLayout();
    }

    public void setScreenAlignment(int alignment) {
        mScreenAlignment = alignment;
    }

    public void setScreenOffset(int offset) {
        mScreenOffset = offset;
        mScreenAlignment = SCREEN_ALIGN_CUSTOMIZED;
    }

    private void updateScreenOffset() {
        switch (mScreenAlignment) {
            case SCREEN_ALIGN_CUSTOMIZED:
                mScrollOffset = mScreenOffset;
                break;
            case SCREEN_ALIGN_LEFT:
                mScrollOffset = 0;
                break;
            case SCREEN_ALIGN_CENTER:
                mScrollOffset = (mScreenContentWidth - mChildScreenMeasureWidth) / 2;
                break;
            case SCREEN_ALIGN_RIGHT:
                mScrollOffset = (mScreenContentWidth - mChildScreenMeasureWidth);
                break;
        }
    }

    private void updateIndicatorPositions(int scrollX, boolean requestLayout) {
        if (getWidth() > 0) {
            final int indexOffset = getScreenCount();
            final int screenWidth = getWidth();
            final int screenHeight = getHeight();

            for (int i = 0; i < mIndicatorCount; i++) {
                View indicator = getChildAt(i + indexOffset);
                final FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) indicator.getLayoutParams();

                final int indicatorWidth = indicator.getMeasuredWidth();
                final int indicatorHeight = indicator.getMeasuredHeight();

                int indicatorLeft = 0;
                int indicatorTop = 0;

                final int gravity = lp.gravity;

                if (gravity != -1) {
                    final int horizontalGravity = gravity & Gravity.HORIZONTAL_GRAVITY_MASK;
                    final int verticalGravity = gravity & Gravity.VERTICAL_GRAVITY_MASK;

                    switch (horizontalGravity) {
                        case Gravity.LEFT:
                            indicatorLeft = lp.leftMargin;
                            break;
                        case Gravity.CENTER_HORIZONTAL:
                            indicatorLeft = (screenWidth - indicatorWidth) / 2
                                            + lp.leftMargin - lp.rightMargin;
                            break;
                        case Gravity.RIGHT:
                            indicatorLeft = screenWidth - indicatorWidth - lp.rightMargin;
                            break;
                        default:
                            indicatorLeft = lp.leftMargin;
                    }

                    switch (verticalGravity) {
                        case Gravity.TOP:
                            indicatorTop = lp.topMargin;
                            break;
                        case Gravity.CENTER_VERTICAL:
                            indicatorTop = (screenHeight - indicatorHeight) / 2
                                            + lp.topMargin - lp.bottomMargin;
                            break;
                        case Gravity.BOTTOM:
                            indicatorTop = screenHeight - indicatorHeight - lp.bottomMargin;
                            break;
                        default:
                            indicatorTop = lp.topMargin;
                    }
                }
                if (!requestLayout && indicator.getHeight() > 0 && indicator.getWidth() > 0) {
                    if (android.os.Build.VERSION.SDK_INT > 16) { //jellybean
                        indicator.setTranslationX(scrollX);
                    } else if (((Indicator) indicator).fastOffset(scrollX + indicatorLeft)) {
                        indicator.invalidate();
                    }
                } else {
                    if (android.os.Build.VERSION.SDK_INT > 16) {
                        scrollX = 0;
                    }
                    indicator.layout(
                            scrollX + indicatorLeft,
                            indicatorTop,
                            scrollX + indicatorLeft + indicatorWidth,
                            indicatorTop + indicatorHeight);
                }
            }
        }
    }

    private void updateSlidePointPosition(int scrollX) {
        // layout the slide point
        int screenCount = getScreenCount();
        if (mSlideBar != null && screenCount > 0) {
            int[] bounds = getSnapBound();
            bounds[1] += mScreenContentWidth;
            int slideBarWidth = mSlideBar.getSlideWidth();
            int visualScreenCount;
            if (mIsGroupUnfolding) {
                visualScreenCount = mGroupEndIndex - mGroupStartIndex + 1;
            } else if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_GROUP) {
                visualScreenCount = getGroupModeVisualScreenSize();
            } else {
                visualScreenCount = screenCount;
            }
            float wholeScreenCount = ((visualScreenCount - 1) + mVisibleRange) / mVisibleRange;
            if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_GROUP && mLayoutScreensSeamless) {
                wholeScreenCount = visualScreenCount * mChildScreenMeasureWidth / ((float) mScreenContentWidth);
            }

            if (wholeScreenCount <=0 ) return;
            float slidePointWidth = Math.min(Math.max(((float)slideBarWidth) / wholeScreenCount,
                    MINIMAL_SLIDE_BAR_POINT_WIDTH), slideBarWidth);
            int screenViewContentWidth = mChildScreenMeasureWidth * visualScreenCount;
            int slidePointX;
            if (screenViewContentWidth <= slideBarWidth)
                slidePointX = 0;
            else {
                float ratio = ((float)scrollX - bounds[0]) / (bounds[1] - bounds[0]);
                float screenIndicatorPos = ratio * slideBarWidth;
                slidePointX = mSlideBar.getSlidePaddingLeft() + (int)screenIndicatorPos;
            }
            if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_PREVIEW) {
                slidePointX = 0;
                slidePointWidth = slideBarWidth;
            }
            float slidePointRight = Math.min(slidePointX + slidePointWidth, slideBarWidth + mSlideBar.getSlidePaddingLeft());
            mSlideBar.setPosition((int)slidePointX, (int)slidePointRight);
            if (slidePointRight - slidePointX == slideBarWidth) {
                mSlideBar.setVisibility(View.INVISIBLE);
            } else {
                mSlideBar.setVisibility(View.VISIBLE);
            }
            if (isHardwareAccelerated()) {
                mSlideBar.invalidate();
            }
        }
    }

    private void updateArrowIndicatorResource(int x) {
        if (mArrowLeft != null) {
            if (mIsGroupUnfolding) {
                mArrowLeft.setImageResource(
                        x <= mScrollLeftBound ? mArrowLeftOffResId : mArrowLeftOnResId);
                mArrowRight.setImageResource(
                        x >= mScrollRightBound ? mArrowRightOffResId : mArrowRightOnResId);
            } else {
                mArrowLeft.setImageResource(
                        x <= 0
                        ? mArrowLeftOffResId
                        : mArrowLeftOnResId);
                int screenCount;
                if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_GROUP) {
                    screenCount = getGroupModeVisualScreenSize();
                } else {
                    screenCount = mScreenCounter;
                }
                mArrowRight.setImageResource(
                        x >= screenCount * mChildScreenMeasureWidth - mScreenContentWidth - mScrollOffset
                        ? mArrowRightOffResId
                        : mArrowRightOnResId);
            }
        }
    }

    public void setOverScrollRatio(float ratio) {
        mOverScrollRatio = ratio;
        requestLayout();
    }

    public void setHasSuffixLinkedScreen(boolean hasLinkedScreen) {
        mHasSuffixLinkedScreen = hasLinkedScreen;
        requestLayout();
    }

    public void setHasPrefixLinkedScreen(boolean hasLinkedScreen) {
        mHasPrefixLinkedScreen = hasLinkedScreen;
        requestLayout();
    }

    protected int[] getSnapBound() {
        int overScrollSize = mIsGroupUnfolding || mScreenLayoutMode == SCREEN_LAYOUT_MODE_PREVIEW ? 0 :
            (int) (mChildScreenMeasureWidth * mOverScrollRatio);
        int[] bounds = new int[2];
        if (mHasSuffixLinkedScreen) {
            bounds[1] = mScrollRightBound - mScreenContentWidth;
        } else {
            bounds[1] = mScrollRightBound - overScrollSize;
        }
        if (mHasPrefixLinkedScreen) {
            bounds[0] = mScrollLeftBound + mScreenContentWidth;
        } else {
            bounds[0] = mScrollLeftBound + overScrollSize;
        }
        return bounds;
    }

    public boolean refreshScrollBound() {
        int screenContentWidth = mScreenContentWidth;
        if (mLayoutScreensSeamless) {
            screenContentWidth = mVisibleRange * mChildScreenMeasureWidth;
        }
        if (mIsGroupUnfolding) {
            reComputeGroupParams();
            mScrollLeftBound = getScreenSnapX(DeviceConfig.isLayoutRtl() ? mGroupEndIndex : mGroupStartIndex);
            if (mLayoutScreensSeamless) {
                int rightOffset = 0;
                if (mGroupEndIndex - mGroupStartIndex + 1 > mVisibleRange) {
                    rightOffset = (mGroupEndIndex - mGroupStartIndex + 1) * mChildScreenMeasureWidth - mScreenContentWidth;
                }
                mScrollRightBound = mScrollLeftBound + rightOffset;
            } else {
                mScrollRightBound = (int) (getVisualIndexInGroupMode(mGroupEndIndex) / mVisibleRange * screenContentWidth);
            }
            if (mLastVisibleRange != mVisibleRange) {
                return true;
            }
            return false;
        }
        int oldLeftBound = mScrollLeftBound;
        int oldRightBound = mScrollRightBound;
        int screenLeftBound = Math.max(mScreenScrollLeftBound, 0);
        int screenRightBound = Math.min(mScreenScrollRightBound, getScreenCount() - 1);
        if (DeviceConfig.isLayoutRtl()) {
            int temp = screenLeftBound;
            screenLeftBound = screenRightBound;
            if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_CENTER ||
                    mScreenLayoutMode == SCREEN_LAYOUT_MODE_FIXED_GAP) {
                screenLeftBound = (screenLeftBound / mVisibleRange + 1) * mVisibleRange - 1;
            }
            screenRightBound = temp;
        }
        int overScrollSize = (int) (mChildScreenMeasureWidth * mOverScrollRatio);
        if (mHasPrefixLinkedScreen) {
            mScrollLeftBound = getScreenSnapX(screenLeftBound) - mScreenContentWidth;
        } else {
            mScrollLeftBound = getScreenSnapX(screenLeftBound) - overScrollSize;
        }
        if (!mScrollWholeScreen) {
            mScrollRightBound = getScreenSnapX(screenRightBound) + overScrollSize + mScrollOffset;
        } else if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_PREVIEW) {
            mScrollRightBound = mScrollLeftBound = mScrollX;
        } else {
            int lastScreenIndex;
            lastScreenIndex = getVisualPosition(screenRightBound);
            if (mHasSuffixLinkedScreen) {
                mScrollRightBound = lastScreenIndex / mVisibleRange * screenContentWidth
                        + mScreenContentWidth;
            } else {
                mScrollRightBound = lastScreenIndex / mVisibleRange * screenContentWidth
                        + overScrollSize;
            }
            if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_GROUP && mLayoutScreensSeamless
                    && lastScreenIndex > mVisibleRange - 1) {
                mScrollRightBound = (lastScreenIndex + 1) * mChildScreenMeasureWidth - mScreenContentWidth
                        + overScrollSize;
            }
        }
        if (mScreenSeekBar != null) {
            if (DeviceConfig.isLayoutRtl()) {
                int temp = screenLeftBound;
                screenLeftBound = screenRightBound;
                screenRightBound = temp;
            }
            int count = getScreenCount();
            for (int i = 0; i < count; i++) {
                final View v = mScreenSeekBar.getChildAt(i);
                if (v != null) {
                    String contentDescription = mContext.getString(R.string.screen_number, i + 1);
                    v.setContentDescription(contentDescription);
                    v.setVisibility(i >= screenLeftBound && i <= screenRightBound ? View.VISIBLE : View.GONE);
                }
            }
        }
        return oldLeftBound != mScrollLeftBound || oldRightBound != mScrollRightBound ||
            mScrollX < mScrollLeftBound;
    }

    public void scrollToScreen(int index) {
        if (mScrollWholeScreen) {
            index = calibrateCurrentScreenIndex(index);
        }
        if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_CENTER || mScreenLayoutMode == SCREEN_LAYOUT_MODE_FIXED_GAP) {
            if (DeviceConfig.isLayoutRtl() && index % mVisibleRange != mVisibleRange - 1) {
                index += mVisibleRange - 1 - index % mVisibleRange;
            }
        }
        int toIndex = getScreenScrollX(index);
        if (toIndex > mScrollRightBound - mChildScreenMeasureWidth * mOverScrollRatio) {
            toIndex = (int) (mScrollRightBound - mChildScreenMeasureWidth * mOverScrollRatio);
        }
        scrollTo(toIndex, 0);
    }

    final private int getScreenScrollX(int index) {
        if (!isScrollable()) {
            return mScrollX;
        } else if ((mScreenLayoutMode == SCREEN_LAYOUT_MODE_CENTER) && mScreenCounter < mVisibleRange) {
            return -mScrollOffset;
        } else if ((mScreenLayoutMode == SCREEN_LAYOUT_MODE_GROUP) && getGroupModeVisualScreenSize() < mVisibleRange) {
            return -mScrollOffset;
        }
        return getScreenSnapX(index) - mScrollOffset;
    }

    final private int getScreenSnapX(int index) {
        int x = getScreenLayoutX(index) - mPaddingLeft - mChildScreenLayoutMeasureDiffX;
        if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_MATRIX) {
            x -=  (int) (1.5f  * mColumnGap);
        } else if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_CENTER) {
            if (getScreenCount() < mVisibleRange) {
                x -= (mScreenContentWidth - getScreenCount() * mChildScreenMeasureWidth) / 2;
            } else {
                x -= (mScreenContentWidth - mVisibleRange * mChildScreenMeasureWidth) / 2;
            }
        } else if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_GROUP) {
            int unfoldingGroupsSize = mIsGroupUnfolding ? mGroupEndIndex - mGroupStartIndex + 1 : 0;
            if (!mIsGroupUnfolding && getGroupModeVisualScreenSize() < mVisibleRange) {
                x -= (mScreenContentWidth - getGroupModeVisualScreenSize() * mChildScreenMeasureWidth) / 2;
            } else if (mIsGroupUnfolding && unfoldingGroupsSize <= mVisibleRange &&
                    index >= mGroupStartIndex && index <= mGroupEndIndex) {
                x -= (mScreenContentWidth - unfoldingGroupsSize * mChildScreenMeasureWidth) / 2;
            } else if (!mLayoutScreensSeamless) {
                x -= (mScreenContentWidth - mVisibleRange * mChildScreenMeasureWidth) / 2;
            }
        } else if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_FIXED_GAP) {
            x -= (mScreenContentWidth - mVisibleRange * mChildScreenMeasureWidth - (mVisibleRange - 1) * mFixedGap) / 2;
        } else if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_CENTER_FIXED_GAP) {
            x -= getFixedGapModeStartPoint();
        }
        return x;
    }

    protected boolean isScrollable() {
        switch (mScreenLayoutMode) {
        case SCREEN_LAYOUT_MODE_PREVIEW:
        case SCREEN_LAYOUT_MODE_UNIFORM:
            return false;
        case SCREEN_LAYOUT_MODE_CENTER:
            if (!mScrollWholeScreen) {
                if (mScreenCounter <= mVisibleRange || mScrollRightBound + mChildScreenMeasureWidth < mScreenContentWidth) {
                    return false;
                }
            }
            break;
        }
        return true;
    }

    protected boolean isScrolling() {
        return !mScroller.isFinished();
    }

    @Override
    public void scrollTo(int x, int y) {
        int oldScrollX = mScrollX;
        if (isScrollable()) {
            int scrollX = Math.max(mScrollLeftBound, Math.min(x, mScrollRightBound));
            mTouchX = scrollX;
            mSmoothingTime = System.nanoTime() / NANOTIME_DIV;
            boolean needTransAnim = mScreenLayoutMode == SCREEN_LAYOUT_MODE_CENTER ||
                    mScreenLayoutMode == SCREEN_LAYOUT_MODE_FIXED_GAP;
            if (DeviceConfig.isLayoutRtl() && oldScrollX > mScrollRightBound && needTransAnim) {
                setTranslationX(mTouchX - oldScrollX);
                animate().translationX(0).start();
            }

            super.scrollTo((int) mTouchX, y);
        }

        if (mPushGestureEnabled && oldScrollX == mScrollX &&
                !mGestureTrigged && getTouchState() == ScreenView.TOUCH_STATE_SCROLLING) {
            mScrollStartX += (x - oldScrollX);
            int[] bounds = getSnapBound();
            if ((mScrollingStateStartX >= bounds[1] && x >= oldScrollX
                    || mScrollingStateStartX <= bounds[0] && x <= oldScrollX)
                    && Math.abs(mScrollStartX - x) / mScreenDensity > GESTURE_PUSH_CONFIRM_DIP) {
                onPushGesture(mScrollStartX - x);
            }
        }
    }

    protected void skipNextAutoLayoutAnimation() {
        if (DeviceConfig.isLayoutRtl() && getScreenCount() % mVisibleRange == 0) {
            for (int i = 0; i < getScreenCount(); i++) {
                if (getScreen(i) instanceof AutoLayoutAnimation.HostView)
                    ((AutoLayoutAnimation.HostView) getScreen(i)).setSkipNextAutoLayoutAnimation(true);
            }
        }
    }

    @Override
    public void computeScroll() {
        if (mScroller.computeScrollOffset()) {
            mTouchX = mScrollX = mScroller.getCurrX();
            mSmoothingTime = System.nanoTime() / NANOTIME_DIV;
            mScrollY = mScroller.getCurrY();
            postInvalidateOnAnimation();
        }
        if (mScroller.isFinished()) {
            if (mNextScreen != INVALID_SCREEN) {
                setCurrentScreenInner(Math.max(0, Math.min(mNextScreen, getScreenCount() - 1)));
                mNextScreen = INVALID_SCREEN;
            } else if (mTouchState == TOUCH_STATE_SCROLLING) {
                final float now = System.nanoTime() / NANOTIME_DIV;
                final float e = (float) Math.exp((now - mSmoothingTime) / SMOOTHING_CONSTANT);
                final float dx = mTouchX - mScrollX;
                mScrollX += dx * e;
                mSmoothingTime = now;
                // Keep generating points as long as we're more than 1px away from the target
                if (dx > 1f || dx < -1f) {
                    postInvalidate();
                }
            }
        }
        updateIndicatorPositions(mScrollX, false);
        updateSlidePointPosition(mScrollX);
        updateArrowIndicatorResource(mScrollX);
    }

    public boolean setUniformLayoutModeMaxGap(int gap) {
        if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_UNIFORM) {
            if (mUniformLayoutModeMaxGap != gap) {
                mUniformLayoutModeMaxGap = gap;
                requestLayout();
                return true;
            }
        }
        return false;
    }

    public int getUniformLayoutModeCurrentGap() {
        return mUniformLayoutModeCurrentGap;
    }

    public int getUniformLayoutModeMaxGap() {
        return mUniformLayoutModeMaxGap;
    }

    int getVisualPosition(int index) {
        if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_GROUP) {
            int maxVisualScreenIndex = getVisualIndexInGroupMode(getScreenCount() - 1);
            int visualIndex = getVisualIndexInGroupMode(index);
            return DeviceConfig.isLayoutRtl() ? maxVisualScreenIndex - visualIndex : visualIndex;
        } else if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_CENTER ||
                mScreenLayoutMode == SCREEN_LAYOUT_MODE_FIXED_GAP) {
            if (DeviceConfig.isLayoutRtl()) {
                if (getScreenCount() <= mVisibleRange) {
                    return getScreenCount() - index - 1;
                }
                int screenCount = getScreenCount() / mVisibleRange + (getScreenCount() % mVisibleRange == 0 ? 0 : 1);
                return mVisibleRange * screenCount - 1 - index;
            }
            return index;
        } else {
            return DeviceConfig.isLayoutRtl() ? getScreenCount() - index - 1 : index;
        }
    }
    protected int getScreenLayoutX(int index) {
        if (mScreenCounter <= 0) return 0;
        int visualIndex = getVisualPosition(index);

        int layoutX = Integer.MIN_VALUE;
        switch (mScreenLayoutMode) {
        case SCREEN_LAYOUT_MODE_CENTER:
            if (mScreenCounter <= mVisibleRange) {
                layoutX = (mScreenContentWidth - mScreenCounter * mChildScreenMeasureWidth) / 2 +
                        visualIndex * mChildScreenMeasureWidth;
            } else {
                layoutX = getMeasuredWidth() * (visualIndex / mVisibleRange) + mPaddingLeft +
                        (mScreenContentWidth - mChildScreenMeasureWidth * mVisibleRange) / 2 +
                        (visualIndex % mVisibleRange) * mChildScreenMeasureWidth;
            }
            break;
        case SCREEN_LAYOUT_MODE_PREVIEW:
            View child = getScreen(index);
            int headerFooterWidth = mScreenContentWidth / mVisibleRange;
            if (child == mPreviewModeHeader) {
                layoutX = mScrollX + mPaddingLeft;
            } else if (child == mPreviewModeFooter) {
                layoutX = mScrollX + mScreenContentWidth + mPaddingLeft - mPaddingRight -
                    (headerFooterWidth + child.getMeasuredWidth()) / 2;
                if (isLayoutRequested() && DeviceConfig.isLayoutRtl()) {
                    layoutX = mScrollX + mPaddingLeft + child.getMeasuredWidth() / 2;
                }
            } else {
                int previewChildWidth = (int) (mChildScreenMeasureWidth * PREVIEW_MODE_MAX_SCREEN_WIDTH);
                int previewCnt = getScreenCount() - (mPreviewModeHeader == null ? 0 : 1) -
                        (mPreviewModeFooter == null ? 0 : 1);
                int headerWidth = mPreviewModeHeader == null ? 0 : headerFooterWidth;
                int footerWidth = mPreviewModeFooter == null ? 0 : headerFooterWidth;
                int previewWidth = mScreenContentWidth - headerWidth - footerWidth;
                previewChildWidth = (int) Math.min((previewWidth - (float)mChildScreenMeasureWidth) /
                        (previewCnt - 1), previewChildWidth);
                layoutX = mScrollX + mPaddingLeft + (DeviceConfig.isLayoutRtl() && mPreviewModeFooter != null ? (headerFooterWidth + child.getMeasuredWidth()) / 2 : 0) + headerWidth +
                        (previewWidth - previewChildWidth * (previewCnt - 1) - mChildScreenMeasureWidth) / 2 +
                        (visualIndex - (mPreviewModeHeader == null ? 0 : 1)) * previewChildWidth;
            }
            break;
        case SCREEN_LAYOUT_MODE_MATRIX:
            int columnIndex = visualIndex % mVisibleRange % mColumnCountPerScreen;
            layoutX = getMeasuredWidth() * (visualIndex / mVisibleRange) + mPaddingLeft +
                    + (int) (1.5f * mColumnGap) +
                    columnIndex * (mChildScreenMeasureWidth + mColumnGap);
            break;
        case SCREEN_LAYOUT_MODE_GROUP:
            columnIndex = visualIndex % mVisibleRange;
            if (mLayoutScreensSeamless) {
                layoutX = visualIndex * mChildScreenMeasureWidth;
            } else {
                layoutX = (int)(getWidth() * (visualIndex / mVisibleRange));
            }

            int unfoldingGroupsSize = mIsGroupUnfolding ? mGroupEndIndex - mGroupStartIndex + 1 : 0;
            if (!mIsGroupUnfolding && getGroupModeVisualScreenSize() < mVisibleRange) {
                int visibleScreenCount = getGroupModeVisualScreenSize();
                layoutX = mPaddingLeft + (mScreenContentWidth - visibleScreenCount * mChildScreenMeasureWidth) / 2 +
                        columnIndex * mChildScreenMeasureWidth;
            } else if (unfoldingGroupsSize <= mVisibleRange &&
                    index >= mGroupStartIndex && index <= mGroupEndIndex) {
                //layout members as center mode if unfolding group size < mVisibleRange
                if (mLayoutScreensSeamless) {
                    layoutX += (mScreenContentWidth - unfoldingGroupsSize * mChildScreenMeasureWidth) / 2;
                } else {
                    layoutX += mPaddingLeft + (mScreenContentWidth - unfoldingGroupsSize * mChildScreenMeasureWidth) / 2 +
                            (index - mGroupStartIndex) * mChildScreenMeasureWidth;
                }
            } else {
                if (!mLayoutScreensSeamless) {
                    int leftMargin = (mScreenContentWidth - mVisibleRange * mChildScreenMeasureWidth) / 2;
                    layoutX += (mPaddingLeft + leftMargin) * (columnIndex >= 0 ? 1 : -1) +
                            columnIndex * mChildScreenMeasureWidth;
                } else if (mIsGroupUnfolding && !DeviceConfig.isLayoutRtl() && index > mGroupEndIndex) {
                    layoutX += mScreenContentWidth % mChildScreenMeasureWidth;
                }
            }
            break;
        case SCREEN_LAYOUT_MODE_UNIFORM:
            mUniformLayoutModeCurrentGap = mScreenContentWidth / mScreenCounter - mChildScreenMeasureWidth;
            if (mScreenCounter > 1) {
                mUniformLayoutModeCurrentGap = Math.min(mUniformLayoutModeCurrentGap, mUniformLayoutModeMaxGap);
            }
            layoutX = Math.round((mPaddingLeft + (visualIndex + 0.5f) * mUniformLayoutModeCurrentGap +
                    mChildScreenMeasureWidth * visualIndex) + (mScreenContentWidth - (mChildScreenMeasureWidth +
                    mUniformLayoutModeCurrentGap) * mScreenCounter) / 2);
            break;
        case SCREEN_LAYOUT_MODE_CENTER_FIXED_GAP:
            int startPoint = getFixedGapModeStartPoint();
            layoutX = startPoint + visualIndex * (mChildScreenMeasureWidth + mFixedGap);
            break;
        case SCREEN_LAYOUT_MODE_FIXED_GAP:
            layoutX = mPaddingLeft + (mScreenContentWidth - mVisibleRange * mChildScreenMeasureWidth - (mVisibleRange - 1) * mFixedGap) / 2 +
                              visualIndex % mVisibleRange * (mChildScreenMeasureWidth + mFixedGap) + visualIndex / mVisibleRange * mScreenContentWidth;
        }
        if (layoutX == Integer.MIN_VALUE) {
            layoutX = (int)(mPaddingLeft + mChildScreenMeasureWidth  * visualIndex + mFixedGap * visualIndex);
            if (!mLayoutScreensSeamless) {
                layoutX += (mPaddingLeft + mPaddingRight) * visualIndex / mVisibleRange;
            }
        }
        return layoutX + mChildScreenLayoutMeasureDiffX;
    }

    private int getFixedGapModeStartPoint() {
        int gapNum = Math.min(mVisibleRange, mScreenCounter) - 1;
        int startPoint = (mScreenContentWidth - (gapNum * mFixedGap + mChildScreenMeasureWidth * (gapNum + 1))) / 2;
        return Math.max(startPoint, mPaddingLeft);
    }

    protected int getScreenLayoutY(int index) {
        int top = mPaddingTop;
        if (mIgnoreCenterY) return top;

        switch (mScreenLayoutMode) {
        case SCREEN_LAYOUT_MODE_CENTER:
        case SCREEN_LAYOUT_MODE_UNIFORM:
        case SCREEN_LAYOUT_MODE_PREVIEW:
        case SCREEN_LAYOUT_MODE_GROUP:
            top += (getHeight() - mChildScreenMeasureHeight - mPaddingTop - mPaddingBottom) / 2;
            break;
        case SCREEN_LAYOUT_MODE_MATRIX:
            top += (int) (1.5f * mRowGap) + (mChildScreenMeasureHeight + mRowGap) *
                    (index % mVisibleRange / mColumnCountPerScreen);
        }
        return top;
    }

    public int getChildScreenMeasureWidth() {
        return mChildScreenMeasureWidth;
    }

    public int getChildScreenMeasureHeight() {
        return mChildScreenMeasureHeight;
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        computeScroll();
        showSlideBar();
    }

    @Override
    public void setVisibility(int visibility) {
        if (visibility == VISIBLE) {
            showSlideBar();
        }
        super.setVisibility(visibility);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int maxHeight = 0;
        int maxWidth = 0;

        final int count = getScreenCount();

        // measure the size of all indicators
        for (int i=0; i < mIndicatorCount; i++) {
            View child = getChildAt(i + count);

            final LayoutParams lp = child.getLayoutParams();

            final int childWidthMeasureSpec = getChildMeasureSpec(
                    widthMeasureSpec, mPaddingLeft + mPaddingRight, lp.width);
            final int childHeightMeasureSpec = getChildMeasureSpec(
                    heightMeasureSpec, mPaddingTop + mPaddingBottom, lp.height);

            child.measure(childWidthMeasureSpec, childHeightMeasureSpec);
            maxWidth = Math.max(maxWidth, child.getMeasuredWidth());
            maxHeight = Math.max(maxHeight, child.getMeasuredHeight());
        }

        // measure the size of all screen
        int maxChildHeight = 0;
        int maxChildWidth = 0;
        for (int i=0; i < count; i++) {
            View child = getChildAt(i);
            final LayoutParams lp = child.getLayoutParams();

            final int childWidthMeasureSpec = getChildMeasureSpec(widthMeasureSpec,
                    mPaddingLeft + mPaddingRight, lp.width);
            final int childHeightMeasureSpec = getChildMeasureSpec(
                    heightMeasureSpec,
                    mPaddingTop + mPaddingBottom,
                    lp.height);

            child.measure(childWidthMeasureSpec, childHeightMeasureSpec);
            maxChildWidth = Math.max(maxChildWidth, child.getMeasuredWidth());
            maxChildHeight = Math.max(maxChildHeight, child.getMeasuredHeight());
        }
        maxWidth = Math.max(maxChildWidth, maxWidth);
        maxHeight = Math.max(maxChildHeight, maxHeight);

        // Account for padding too
        maxWidth += mPaddingLeft + mPaddingRight;
        maxHeight += mPaddingTop + mPaddingBottom;

        setMeasuredDimension(
                resolveSize(maxWidth, widthMeasureSpec),
                resolveSize(maxHeight, heightMeasureSpec));

        if (count > 0) {
            mChildScreenMeasureWidth = maxChildWidth;
            mChildScreenMeasureHeight = maxChildHeight;
            mChildScreenLayoutMeasureDiffX = 0;
            mScreenContentWidth = MeasureSpec.getSize(widthMeasureSpec) - mPaddingLeft - mPaddingRight;
            mScreenContentHeight = MeasureSpec.getSize(heightMeasureSpec) - mPaddingTop - mPaddingBottom;
            mLastVisibleRange = mVisibleRange;

            if (mChildScreenMeasureWidth > 0) {
                if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_MATRIX) {
                    mRowCountPerScreen = mScreenContentHeight / mChildScreenMeasureHeight;
                    mColumnCountPerScreen = mScreenContentWidth / mChildScreenMeasureWidth;
                    mVisibleRange = mRowCountPerScreen * mColumnCountPerScreen;
                    mRowGap = (mScreenContentHeight - mRowCountPerScreen * mChildScreenMeasureHeight) / (mRowCountPerScreen + 2);
                    mColumnGap = (mScreenContentWidth - mColumnCountPerScreen * mChildScreenMeasureWidth) / (mColumnCountPerScreen + 2);
                } else if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_FIXED_GAP) {
                    mVisibleRange = Math.max(1, (mScreenContentWidth + mFixedGap) / (mChildScreenMeasureWidth + mFixedGap));
                }else {
                    mVisibleRange = Math.max(1, mScreenContentWidth / mChildScreenMeasureWidth);
                    if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_CENTER && mScreenCounter > mVisibleRange) {
                        mChildScreenMeasureWidth = mScreenContentWidth / mVisibleRange;
                        mChildScreenLayoutMeasureDiffX = (mChildScreenMeasureWidth - maxChildWidth) / 2;
                    }
                }
            }
            setOverScrollRatio(mOverScrollRatio);
            updateScreenOffset();
        }
    }

    private void correctCurrentScreen(boolean forceCorrect) {
        int currentScreen = mCurrentScreen == INVALID_SCREEN ? getDefaultScreenIndex() : mCurrentScreen;
        if (mScrollWholeScreen) {
            currentScreen = calibrateCurrentScreenIndex(currentScreen);
        }
        if (currentScreen != mCurrentScreen || forceCorrect)
            setCurrentScreen(currentScreen);
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        setFrame(left, top, right, bottom);

        updateIndicatorPositions(mScrollX, true);

        final int count = getScreenCount();
        if (count <= 0) return;

        final boolean boundChanged = refreshScrollBound();
        correctCurrentScreen(boundChanged);
        // layout all children of screen item
        for (int i = 0; i < count; i++) {
            final View child = getChildAt(i);
            if (child == null) break;

            if (child.getVisibility() != View.GONE) {
                int layoutTop = getScreenLayoutY(i);
                int layoutLeft = getScreenLayoutX(i);
                if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_GROUP) {
                    if (mGroups.containsKey(child) && mGroups.get(child).size() > 0) {
                        ArrayList<View> groupMembers = mGroups.get(child);
                        int offsetX = (int)(mChildScreenMeasureWidth * GROUP_MODE_OVERLAY_RATIO /
                                (groupMembers.size() > GROUP_MODE_MAX_MEMBER_SIZE ?
                                        GROUP_MODE_MAX_MEMBER_SIZE : groupMembers.size()));
                        if (offsetX > GROUP_MODE_DEFAULT_OFFSET_X) {
                            offsetX = GROUP_MODE_DEFAULT_OFFSET_X;
                        }
                        int pos = 1;
                        for (View v : groupMembers) {
                            if (pos > GROUP_MODE_MAX_MEMBER_SIZE) {
                                v.layout(layoutLeft, layoutTop,
                                        layoutLeft + v.getMeasuredWidth(), layoutTop + v.getMeasuredHeight());
                            } else {
                                v.layout(layoutLeft + pos * offsetX, layoutTop,
                                    layoutLeft + v.getMeasuredWidth() + pos * offsetX,
                                    layoutTop + v.getMeasuredHeight());
                            }
                            pos ++;
                        }
                        i += groupMembers.size();
                    }
                }
                child.layout(layoutLeft, layoutTop,
                    layoutLeft + child.getMeasuredWidth(), layoutTop + child.getMeasuredHeight());
            } else {
//                throw new RuntimeException("child screen can't set visible as GONE.");
            }
        }
    }

    @Override
    protected boolean drawChild(Canvas canvas, View child, long drawingTime) {
        updateChildStaticTransformation(child);
        return super.drawChild(canvas, child, drawingTime);
    }

    @Override
    public boolean requestChildRectangleOnScreen(View child, Rect rectangle, boolean immediate) {
        int screen = indexOfChild(child);
        if (screen < getScreenCount()) {
            if (screen != mCurrentScreen || !mScroller.isFinished()) {
                snapToScreen(screen);
                return true;
            }
            return false;
        }
        return super.requestChildRectangleOnScreen(child, rectangle, immediate);
    }

    @Override
    public boolean dispatchUnhandledMove(View focused, int direction) {
        if (direction == View.FOCUS_LEFT) {
            if (mCurrentScreen > 0) {
                snapToScreen(mCurrentScreen - 1);
                return true;
            }
        } else if (direction == View.FOCUS_RIGHT) {
            if (mCurrentScreen < getScreenCount() - 1) {
                snapToScreen(mCurrentScreen + 1);
                return true;
            }
        }
        return super.dispatchUnhandledMove(focused, direction);
    }

    protected int getTouchState() {
        return mTouchState;
    }

    protected void setTouchState(MotionEvent ev, int touchState) {
        if (mTouchState != touchState && touchState == TOUCH_STATE_SCROLLING) {
            mScrollingStateStartX = mScrollX;
        }
        mTouchState = touchState;

        getParent().requestDisallowInterceptTouchEvent(mTouchState != TOUCH_STATE_REST);
        if (mTouchState == TOUCH_STATE_REST) {
            mActivePointerId = INVALID_POINTER;
            mAllowLongPress = false;
            mGestureVelocityTracker.recycle();
        }
        else {
            if (ev != null) {
                mActivePointerId = ev.getPointerId(0);
            }

            // cancel any pending longpress
            if (mAllowLongPress) {
                mAllowLongPress = false;
                // Try canceling the long press. It could also have been scheduled
                // by a distant descendant, so use the mAllowLongPress flag to block
                // everything
                final View currentScreen = getChildAt(mCurrentScreen);
                if (currentScreen != null) currentScreen.cancelLongPress();
            }

            if (mTouchState == TOUCH_STATE_SCROLLING) {
                mLastMotionX = ev.getX(ev.findPointerIndex(mActivePointerId));
                mTouchX = mScrollX;
                mSmoothingTime = System.nanoTime() / NANOTIME_DIV;
            }
        }

        showSlideBar();
        if (mPushGestureEnabled &&
                touchState == ScreenView.TOUCH_STATE_SCROLLING) {
            mGestureTrigged = false;
            mScrollStartX = mScrollX;
        }
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        switch (ev.getAction() & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_MOVE: {
                if (mSecondPointerStartX == INVALID_SIZE && ev.getPointerCount() > 1) {
                    mSecondPointerStartX = ev.getX(1);
                }
                onTouchEventUnique(ev);
                break;
            }

            case MotionEvent.ACTION_DOWN: {
                ev.setAction(MotionEvent.ACTION_CANCEL);
                mScaleDetector.onTouchEvent(ev);
                ev.setAction(MotionEvent.ACTION_DOWN);
                mGestureVelocityTracker.recycle();

                mCurrentGestureFinished = false;
                mTouchIntercepted = false;

                // Remember location of down touch
                mSecondPointerStartX = INVALID_SIZE;
                mLastMotionX = ev.getX();
                mLastMotionY = ev.getY();

                if (mScroller.isFinished()) {
                    mAllowLongPress = true;
                }
                else {
                    /*
                     * If being flinged and user touches the screen, initiate drag;
                     * otherwise don't.  mScroller.isFinished should be false when
                     * being flinged.
                     */
                    mScroller.abortAnimation();
                    setTouchState(ev, TOUCH_STATE_SCROLLING);
                }
                break;
            }

            case MotionEvent.ACTION_CANCEL:
            case MotionEvent.ACTION_UP:
                setTouchState(ev, TOUCH_STATE_REST);
                break;
        }

        if (MotionEvent.ACTION_MOVE != (ev.getAction() & MotionEvent.ACTION_MASK)) {
            onTouchEventUnique(ev);
        }

        return mCurrentGestureFinished
               || (mTouchState != TOUCH_STATE_REST && mTouchState != TOUCH_STATE_SLIDING);
    }

    protected boolean scrolledFarEnough(MotionEvent ev) {
        final float dx = Math.abs(ev.getX(0) - mLastMotionX);
        final float dy = Math.abs(ev.getY(0) - mLastMotionY);
        if (ev.getPointerCount() > 1) {
            if (!((ev.getX(0) - mLastMotionX < 0 && ev.getX(1) - mSecondPointerStartX < 0)
                    || (ev.getX(0) - mLastMotionX > 0 && ev.getX(1) - mSecondPointerStartX > 0))) {
                return false;
            }
            float secondDX = Math.abs(ev.getX(1) - mSecondPointerStartX);
            if (secondDX < mTouchSlop * ev.getPointerCount()) {
                return false;
            }
        }
        return dx > dy * mConfirmHorizontalScrollRatio && dx > mTouchSlop * ev.getPointerCount();
    }

    private void onTouchEventUnique(MotionEvent ev) {
        mGestureVelocityTracker.addMovement(ev);

        if (TOUCH_STATE_REST == mTouchState || TOUCH_STATE_PINCHING == mTouchState) {
            mScaleDetector.onTouchEvent(ev);
        }

        if (ev.getAction() == MotionEvent.ACTION_MOVE && mTouchState == TOUCH_STATE_REST) {
            if (scrolledFarEnough(ev)) {
                setTouchState(ev, TOUCH_STATE_SCROLLING);
            } else {
                int vf = mGestureVelocityTracker.getVerticalGesture();
                if (vf != GestureVelocityTracker.FLING_NONE) {
                    if (onVerticalGesture(vf, ev)) {
                        setTouchState(ev, TOUCH_STATE_CANCLED);
                    }
                }
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (mCurrentGestureFinished) return true;

        if (mTouchIntercepted) {
            onTouchEventUnique(ev);
        }

        switch (ev.getAction() & MotionEvent.ACTION_MASK) {
        case MotionEvent.ACTION_DOWN:
            break;

        case MotionEvent.ACTION_MOVE:
            if (mTouchState == TOUCH_STATE_REST && scrolledFarEnough(ev)) {
                setTouchState(ev, TOUCH_STATE_SCROLLING);
            }

            if (mTouchState == TOUCH_STATE_SCROLLING) {
                // Scroll to follow the motion event
                int pointerIndex = ev.findPointerIndex(mActivePointerId);
                if(pointerIndex == INVALID_POINTER) {
                    setTouchState(ev, TOUCH_STATE_SCROLLING);
                    pointerIndex = ev.findPointerIndex(mActivePointerId);
                }
                final float x = ev.getX(pointerIndex);
                float deltaX = mLastMotionX - x;
                mLastMotionX = x;

                if (deltaX != 0) {
                    deltaX = recalculateDeltaX(deltaX);
                    scrollTo(Math.round(mTouchX + deltaX), 0);
                } else {
                    awakenScrollBars();
                }
            }
            break;
        case MotionEvent.ACTION_CANCEL:
            if (mTouchState == TOUCH_STATE_SCROLLING) {
                mScroller.abortAnimation();
                final int velocityX = (int) mGestureVelocityTracker.getXVelocity(
                        1000, mMaximumVelocity, mActivePointerId);
                snapByVelocity(velocityX, GestureVelocityTracker.FLING_CANCEL);
            }
            setTouchState(ev, TOUCH_STATE_REST);
            break;
        case MotionEvent.ACTION_UP:
            if (mTouchState == TOUCH_STATE_SCROLLING) {
                snapByVelocity(mActivePointerId);
            }
            setTouchState(ev, TOUCH_STATE_REST);
            break;
        case MotionEvent.ACTION_POINTER_UP:
            final int pointerIndex = (ev.getAction() & MotionEvent.ACTION_POINTER_INDEX_MASK)
                                     >> MotionEvent.ACTION_POINTER_INDEX_SHIFT;
            final int pointerId = ev.getPointerId(pointerIndex);
            if (pointerId == mActivePointerId) {
                // This was our active pointer going up. Choose a new
                // active pointer and adjust accordingly.
                // TODO: Make this decision more intelligent.
                final int newPointerIndex = pointerIndex == 0 ? 1 : 0;
                mLastMotionX = ev.getX(newPointerIndex);
                mActivePointerId = ev.getPointerId(newPointerIndex);
                mGestureVelocityTracker.init(mActivePointerId);
            }
            break;
        }

        mTouchIntercepted = true;
        return true;
    }

    @Override
    protected boolean isTransformedTouchPointInView(float x, float y, View child,
            PointF outLocalPoint) {
        if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_GROUP &&
                mEnableReverseDrawingMode) {
            for (ArrayList<View> members : mGroups.values()) {
                if (members.contains(child)) {
                    return false;
                }
            }
        }
        return super.isTransformedTouchPointInView(x, y, child, outLocalPoint);
    }

    public void onSecondaryPointerDown(MotionEvent ev, int pointerId) {
        mLastMotionX = ev.getX(ev.findPointerIndex(pointerId));
        mTouchX = mScrollX;
        mSmoothingTime = System.nanoTime() / NANOTIME_DIV;
        mGestureVelocityTracker.init(pointerId);
        mGestureVelocityTracker.addMovement(ev);
        mTouchState = TOUCH_STATE_SCROLLING;
    }

    public void onSecondaryPointerUp(MotionEvent ev, int pointerId) {
        snapByVelocity(pointerId);
        mGestureVelocityTracker.recycle();
        mTouchState = TOUCH_STATE_REST;
    }

    public void onSecondaryPointerMove(MotionEvent ev, int pointerId) {
        final float x = ev.getX(ev.findPointerIndex(pointerId));
        final float deltaX = mLastMotionX - x;
        mLastMotionX = x;

        if (deltaX != 0) {
            scrollTo((int) (mTouchX + deltaX), 0);
        } else {
            awakenScrollBars();
        }

        mGestureVelocityTracker.addMovement(ev);
    }

    private void snapByVelocity(int pointerId) {
        if (mChildScreenMeasureWidth <= 0 || getCurrentScreen() == null || !isScrollable()) {
            return;
        }

        final int velocityX = (int) mGestureVelocityTracker.getXVelocity(1000, mMaximumVelocity, pointerId);
        final int flingDirection = mGestureVelocityTracker.getXFlingDirection(Math.abs(velocityX));
        snapByVelocity(velocityX, flingDirection);
    }

    protected void snapByVelocity(int velocity, int flingDirection) {
        int snapGap = mScrollWholeScreen ? mVisibleRange : 1;
        if (flingDirection == GestureVelocityTracker.FLING_LEFT) {
            int toIndex  = getSnapToScreenIndex(mCurrentScreen, snapGap,
                    DeviceConfig.isLayoutRtl() ? SNAP_DIRECTION_RIGHT : SNAP_DIRECTION_LEFT);
            snapToScreen(toIndex, velocity, true);
        } else if (flingDirection == GestureVelocityTracker.FLING_RIGHT) {
            int toIndex = getSnapToScreenIndex(mCurrentScreen, snapGap,
                    DeviceConfig.isLayoutRtl() ? SNAP_DIRECTION_LEFT : SNAP_DIRECTION_RIGHT);
            snapToScreen(toIndex, velocity, true);
        } else if (flingDirection == GestureVelocityTracker.FLING_CANCEL) {
            snapToScreen(mCurrentScreen, velocity, true);
        } else {
            int whichScreen = getSnapUnitIndex(snapGap);
            if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_GROUP) {
                whichScreen = getScreenActualIndexInGroupMode(whichScreen);
            }
            snapToScreen(whichScreen, 0, true);
        }
    }

    protected int getSnapUnitIndex(int snapGap) {
        int snapUnit = mChildScreenMeasureWidth * snapGap;
        return (mScrollX + (snapUnit >> 1)) / mChildScreenMeasureWidth;
    }

    protected void finishCurrentGesture() {
        mCurrentGestureFinished = true;
        setTouchState(null, TOUCH_STATE_REST);
    }

    public int snapToScreen(int whichScreen) {
        return snapToScreen(whichScreen, 0, false);
    }

//    public int snapToScreen(CellScreen cellScreen) {
//        if (cellScreen != null) {
//            return snapToScreen(getChildIndex(cellScreen), 0, false);
//        }
//        return 0;
//    }

    protected int getSnapOverScroll() {
        return 0;
    }

    protected int snapToScreen(int whichScreen, int velocity, boolean settle) {
        if (mScreenContentWidth <= 0) {
            return 0;
        }

        if (mIsGroupUnfolding) {
            whichScreen = Math.min(Math.max(whichScreen, mGroupStartIndex), mGroupEndIndex);
        }
        if (mScrollWholeScreen) {
            mNextScreen = calibrateCurrentScreenIndex(whichScreen);
        } else {
            mNextScreen = Math.max(0, Math.min(whichScreen, getScreenCount() - mVisibleRange));
        }

        if (mScreenLayoutMode != SCREEN_LAYOUT_MODE_GROUP) {
            mNextScreen = Math.max(mScreenScrollLeftBound, Math.min(mScreenScrollRightBound, mNextScreen));
        }

        int screenDelta;
        if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_GROUP) {
            screenDelta = Math.max(1, Math.abs(getVisualIndexInGroupMode(mNextScreen) -
                    getVisualIndexInGroupMode(mCurrentScreen)));
        } else {
            screenDelta = Math.max(1, Math.abs(mNextScreen - mCurrentScreen));
        }
        if (!mScroller.isFinished()) {
            mScroller.abortAnimation();
        }

        velocity = Math.abs(velocity);

        if (settle) {
            mScreenViewOvershootInterpolator.setDistance(screenDelta, velocity);
        } else {
            mScreenViewOvershootInterpolator.disableSettle();
        }

        int[] bounds = getSnapBound();
        if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_CENTER ||
                mScreenLayoutMode == SCREEN_LAYOUT_MODE_FIXED_GAP) {
            if (DeviceConfig.isLayoutRtl() && mNextScreen % mVisibleRange != mVisibleRange - 1) {
                mNextScreen += mVisibleRange - 1 - mNextScreen % mVisibleRange;
            }
        }
        final int newX = Math.max(bounds[0], Math.min(bounds[1],
                getScreenScrollX(mNextScreen) + getSnapOverScroll()));
        final int delta = newX - mScrollX;
        if (newX == bounds[0] || newX == bounds[1]) {
            mSnapDelta = 0;
        } else {
            mSnapDelta = getSnapOverScroll();
        }
        if (delta == 0) {
            return 0;
        }
        int duration = getSnapDuration(delta, velocity);
        startScroll(mScrollX, 0, delta, 0, duration);
        invalidate();
        return duration;
    }

    protected int getSnapDuration(int delta, int velocity) {
        int duration = (int) Math.min(Math.abs(delta) * mScreenSnapDuration /
                mScreenContentWidth, getScreenSnapMaxDuration());
        if (velocity > 0) {
            duration += (int) ((duration / (velocity / BASELINE_FLING_VELOCITY))
                    * FLING_VELOCITY_INFLUENCE);
        }
        return duration;
    }

    protected int getScreenSnapDuration() {
        return mScreenSnapDuration;
    }

    protected int getSnapDelta() {
        return mSnapDelta;
    }

    protected void startScroll(int startX, int startY, int dx, int dy, int duration) {
        mScroller.startScroll(startX, startY, dx, dy, duration);
    }

    final public int getScreenCount() {
        return mScreenCounter;
    }

    public int getChildIndex(View v) {
        for (int i = 0; i < getScreenCount(); i ++) {
            View screen = getScreen(i);
            if (screen == v) {
                return i;
            }
        }
        return -1;
    }
    /**
     * Returns the index of the currently displayed screen.
     *
     * @return The index of the currently displayed screen.
     */
    public int getCurrentScreenIndex() {
        if(mNextScreen != INVALID_SCREEN){
            return mNextScreen;
        }
        return mCurrentScreen;
    }

    public View getCurrentScreen() {
        return getScreen(mCurrentScreen);
    }

    protected int getDefaultScreenIndex() {
        return 0;
    }

    /**
     * Sets the current screen.
     *
     * @param currentScreen
     */
    public void setCurrentScreen(int screenIndex) {
        if (mScrollWholeScreen) {
            screenIndex = calibrateCurrentScreenIndex(screenIndex);
        } else {
            screenIndex = Math.max(0, Math.min(screenIndex, getScreenCount() - mVisibleRange));
        }

        setCurrentScreenInner(screenIndex);
        mScroller.abortAnimation();
        scrollToScreen(mCurrentScreen);
    }

    protected void setCurrentScreenInner(int screenIndex) {
        updateSeekPoints(screenIndex);
        mCurrentScreen = screenIndex;
        mNextScreen = INVALID_SCREEN;
    }

    public View getScreen(int screenIndex) {
        if (screenIndex < 0 || screenIndex >= getScreenCount()) {
            return null;
        }
        return getChildAt(screenIndex);
    }

    public int getVisibleRange() {
        return mVisibleRange;
    }

    public void addView(View child, int index, LayoutParams params) {
        int currentCount = getScreenCount();
        if (index < 0) {
            index = currentCount;
        }
        else {
            index = Math.min(index, currentCount);
        }

        if (mScreenSeekBar != null) {
            mScreenSeekBar.addView(createSeekPoint(), index, SEEK_POINT_LAYOUT_PARAMS);
        }

        ++mScreenCounter;
        if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_GROUP)
            mGroupModeVisualScreenSize = INVALID_SIZE;

        super.addView(child, index, params);
    }

    /**
     * Override all methods for directly adding/removing views to
     * force user adding screen or indicator explicitly
     */
    public void removeView(View view) {
        if (view instanceof Indicator) {
            throwRemoveIndicatorException();
        }
        super.removeView(view);
    }
    public void removeViewInLayout(View view) {
        if (view instanceof Indicator) {
            throwRemoveIndicatorException();
        }
        super.removeView(view);
    }
    public void removeViewsInLayout(int start, int count) {
        if (start + count >= getScreenCount()) {
            throwRemoveIndicatorException();
        }
        super.removeViewsInLayout(start, count);
    }
    public void removeViewAt(int index) {
        if (index >= getScreenCount()) {
            throwRemoveIndicatorException();
        }
        super.removeViewAt(index);
    }
    public void removeViews(int start, int count) {
        if (start + count >= getScreenCount()) {
            throwRemoveIndicatorException();
        }
        super.removeViews(start, count);
    }

    @Override
    public void onViewRemoved(View child) {
        if (child instanceof Indicator) {
            mIndicatorCount--;
        } else {
            mScreenCounter--;
            if (mScreenLayoutMode == SCREEN_LAYOUT_MODE_GROUP)
                mGroupModeVisualScreenSize = INVALID_SIZE;
        }
    }

    private void throwRemoveIndicatorException() {
        throw new UnsupportedOperationException("ScreenView doesn't support remove indicator directly.");
    }

    public void addIndicator(View indicator, FrameLayout.LayoutParams params) {
        mIndicatorCount++;
        super.addView(indicator, -1, params);
    }

    public void addIndicatorAt(View indicator, FrameLayout.LayoutParams params, int index) {
        index = Math.max(-1, Math.min(index, mIndicatorCount));
        if (index >= 0) {
            index += getScreenCount();
        }

        mIndicatorCount++;
        super.addView(indicator, index, params);
    }

    public void removeIndicator(View indicator) {
        final int index = indexOfChild(indicator);
        if (index < getScreenCount()) {
            throw new InvalidParameterException("The view passed through the parameter must be indicator.");
        }

        mIndicatorCount--;
        super.removeViewAt(index);
    }

    public void removeScreen(int screenIndex) {
        if (screenIndex >= getScreenCount()) {
            throw new InvalidParameterException("The view specified by the index must be a screen.");
        }

        if (screenIndex == mCurrentScreen) {
            if (!mScrollWholeScreen) {
                if (screenIndex == getScreenCount() - 1)
                    setCurrentScreen(Math.max(0, screenIndex - 1));
            } else {
                if (screenIndex != 0 && screenIndex == getScreenCount() - 1) {
                    // this.setCurrentScreen(Math.max(0, screenIndex - 1));
                    snapToScreen(screenIndex - 1);
                }
            }
        }

        if (mScreenSeekBar != null) {
            mScreenSeekBar.removeViewAt(screenIndex);
        }
        super.removeViewAt(screenIndex);
    }

    public void removeAllScreens() {
        if (getScreenCount() <= 0) return;
        removeScreensInLayout(0, getScreenCount());
        requestLayout();
        invalidate();
    }

    public View[] removeOutAllScreens() {
        View children[] = new View[getScreenCount()];
        for (int i = 0;i < getScreenCount(); i++) {
            children[i] = getScreen(i);
        }
        removeAllScreens();
        return children;
    }

    public void removeScreensInLayout(int start, int count) {
        if (start < 0 || start >= getScreenCount()) return;
        count = Math.min(count, getScreenCount() - start);

        if (mScreenSeekBar != null) {
            mScreenSeekBar.removeViewsInLayout(start, count);
        }
        super.removeViewsInLayout(start, count);
    }

    /**
     * @return True is long presses are still allowed for the current touch
     */
    public boolean allowLongPress() {
        return mAllowLongPress;
    }

    /**
     * Set true to allow long-press events to be triggered, usually checked by
     * {@link Launcher} to accept or block dpad-initiated long-presses.
     */
    public void setAllowLongPress(boolean allowLongPress) {
        mAllowLongPress = allowLongPress;
    }

    /**
     * Registers the specified listener on each screen contained in this workspace.
     *
     * @param l The listener used to respond to long clicks.
     */
    @Override
    public void setOnLongClickListener(OnLongClickListener l) {
        mLongClickListener = l;
        final int count = getScreenCount();
        for (int i = 0; i < count; i++) {
            getChildAt(i).setOnLongClickListener(l);
        }
    }

    private ImageView createSeekPoint() {
        ImageView seekPoint = new ImageView(mContext);
        seekPoint.setScaleType(ScaleType.CENTER);
        seekPoint.setImageResource(mSeekPointResId);
        seekPoint.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                snapToScreen(mScreenSeekBar.indexOfChild(v));
            }
        });
        return seekPoint;
    }

    private void updateSeekPoints(int newPos) {
        if (mScreenSeekBar != null) {
            int count = getScreenCount();
            for (int i = 0; i < count; i++) {
                final View v = mScreenSeekBar.getChildAt(i);
                if (v != null) {
                    v.setSelected(i >= newPos && i < newPos + mVisibleRange);
                }
            }
        }
    }

    public void onResume(){
    }

    public void onPause(){
        if(!mScroller.isFinished()){
            setCurrentScreen((int)Math.floor((mScroller.getCurrX() +
                    mChildScreenMeasureWidth / 2) / mChildScreenMeasureWidth));
            mScroller.abortAnimation();
        }
    }

    public int getScreenTransitionType() {
        return mTransitionEffect.getTransitionType();
    }

    public int setScreenTransitionType(int type) {
        int resultType = mTransitionEffect.setTransitionType(type);
        setOvershootTension(mTransitionEffect.getOverShotTension());
        setScreenSnapDuration(mTransitionEffect.getScreenSnapDuration());
        return resultType;
    }

    public void appendScreenTransitionType(int type) {
        mTransitionEffect.appendTransitionType(type);
        setOvershootTension(mTransitionEffect.getOverShotTension());
        setScreenSnapDuration(mTransitionEffect.getScreenSnapDuration());
    }

    public void removeScreenTransitionType(int type) {
        mTransitionEffect.removeTransitionType(type);
        if (mTransitionEffect.isValidType()) {
            setOvershootTension(mTransitionEffect.getOverShotTension());
            setScreenSnapDuration(mTransitionEffect.getScreenSnapDuration());
        }
    }

    protected void updateChildStaticTransformation(View child) {
        if (child instanceof Indicator) {
            return;
        }
        final float childW = child.getMeasuredWidth();
        final float halfScreenW = getMeasuredWidth() / 2.0f;
        final float halfChildW = childW / 2.0f;
        float interpolation = (mScrollX + halfScreenW - child.getLeft() - halfChildW) / childW;
        mTransitionEffect.updateTransformation(interpolation,
                mScrollX - mLastScrollX, mLastMotionX, mLastMotionY - getPaddingTop(), child, this);
    }

    public void setEnableReverseDrawingMode(boolean isReverse) {
        setChildrenDrawingOrderEnabled(isReverse);
        mEnableReverseDrawingMode = isReverse;
    }

    @Override
    protected int getChildDrawingOrder(int childCount, int i) {
        if (mEnableReverseDrawingMode) {
            return childCount - i - 1;
        }
        return i;
    }

    private class SliderTouchListener implements OnTouchListener {

        public boolean onTouch(View v, MotionEvent event) {
            final int sliderWidth = v.getWidth();
            final float x = Math.max(0, Math.min(event.getX(), sliderWidth - 1));
            final int screenCount = getScreenCount();
            final int pos = (int) Math.floor(screenCount * x / sliderWidth);

            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    if (!mScroller.isFinished()) mScroller.abortAnimation();
                    setTouchState(event, TOUCH_STATE_SLIDING);
                    break;
                case MotionEvent.ACTION_MOVE: {
                    setCurrentScreenInner(pos);
                    scrollTo((int)(screenCount * mChildScreenMeasureWidth * x
                            / sliderWidth - mChildScreenMeasureWidth / 2), 0);
                    break;
                }
                case MotionEvent.ACTION_CANCEL:
                case MotionEvent.ACTION_UP: {
                    snapToScreen(pos);
                    updateSeekPoints(mNextScreen);
                    break;
                }
            }
            return true;
        }
    }

    protected int getScrollStartX() {
        return mScrollStartX;
    }

    protected void onPushGesture(int direction) {
    }

    protected boolean onVerticalGesture(int direction, MotionEvent event) {
        return false;
    }

    protected void onPinchIn(ScaleGestureDetector detector) {
    }

    protected void onPinchOut(ScaleGestureDetector detector) {
    }

    private class ScaleDetectorListener implements ScaleGestureDetector.OnScaleGestureListener {
        private static final float VALID_PINCH_TIME = 200;
        private static final float VALID_PINCH_RATIO = 0.95f;

        private static final float VALID_PINCH_IN_RATIO = 0.8f;
        private static final float VALID_PINCH_OUT_RATIO = 1.2f;

        public boolean onScaleBegin(ScaleGestureDetector detector) {
            return TOUCH_STATE_REST == mTouchState;
        }

        public void onScaleEnd(ScaleGestureDetector detector) {
            finishCurrentGesture();
        }

        public boolean onScale(ScaleGestureDetector detector) {
            float scale = detector.getScaleFactor();
            if (TOUCH_STATE_REST == mTouchState
                && (detector.getTimeDelta() > VALID_PINCH_TIME
                    || scale < VALID_PINCH_RATIO
                    || scale > 1 / VALID_PINCH_RATIO)) {
                setTouchState(null, TOUCH_STATE_PINCHING);
            }

            if (scale < VALID_PINCH_IN_RATIO) {
                onPinchIn(detector);
                return true;
            }

            if (scale > VALID_PINCH_OUT_RATIO) {
                onPinchOut(detector);
                return true;
            }

            return false;
        }
    }

    protected Parcelable onSaveInstanceState() {
        final SavedState state = new SavedState(super.onSaveInstanceState());
        state.currentScreen = mCurrentScreen;
        return state;
    }

    @Override
    protected void onRestoreInstanceState(Parcelable state) {
        SavedState savedState = (SavedState) state;
        super.onRestoreInstanceState(savedState.getSuperState());
        if (savedState.currentScreen != -1) {
            setCurrentScreen(savedState.currentScreen);
        }
    }

    public static class SavedState extends BaseSavedState {
        int currentScreen = -1;

        SavedState(Parcelable superState) {
            super(superState);
        }

        private SavedState(Parcel in) {
            super(in);
            currentScreen = in.readInt();
        }

        @Override
        public void writeToParcel(Parcel out, int flags) {
            super.writeToParcel(out, flags);
            out.writeInt(currentScreen);
        }

        public static final Parcelable.Creator<SavedState> CREATOR =
                new Parcelable.Creator<SavedState>() {
            public SavedState createFromParcel(Parcel in) {
                return new SavedState(in);
            }

            public SavedState[] newArray(int size) {
                return new SavedState[size];
            }
        };
    }

    public void setChildScaleX(float childScaleX) {
        mChildScaleX = childScaleX;
    }

    private float recalculateDeltaX(float deltaX) {
        if (isSpringOverScroll()) {
            int overScrollSize = (int) (mChildScreenMeasureWidth * mOverScrollRatio);
            float leftBound = mScrollLeftBound + overScrollSize;
            float rightBound = mScrollRightBound - overScrollSize;
            float ratio = 1.0f;
            float targetX = mTouchX + deltaX;
            if (targetX > rightBound) {
                ratio = 1 - (targetX - rightBound) / overScrollSize;
            } else if (targetX < leftBound) {
                ratio = 1 - (leftBound - targetX) / overScrollSize;
            }
            return ratio * deltaX;
        } else {
            return deltaX;
        }
    }

    public static int getDipPixelSize(int dip) {
        return Math.round(dip * DeviceConfig.getScreenDensity());
     }
    public static int getDipPixelSize(float dip) {
        return Math.round(dip * DeviceConfig.getScreenDensity());
     }

    protected boolean isSpringOverScroll() {
        return false;
    }
}
