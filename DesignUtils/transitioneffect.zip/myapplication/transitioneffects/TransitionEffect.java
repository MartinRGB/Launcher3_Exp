package com.example.martinrgb.myapplication.transitioneffects;

import android.view.View;
import android.view.ViewGroup;

public abstract class TransitionEffect {
    public static final float DEFAULT_OVER_SHOOT_TENSION = 1.3f;
    public static final int DEFAULT_SCREEN_SNAP_DURATION = 500;

    public TransitionEffect mPreEffect = null;

    public abstract void updateTransformation(float interpolation, float deltaX, float touchX,
            float touchY, View child, ViewGroup group);
    public abstract float getOverShotTension();
    public abstract int getScreenSnapDuration();
    public abstract void resetTransformation(View child, ViewGroup group);

    protected void resetTransformationView(View child) {
        if (mPreEffect != null && mPreEffect != this) {
            mPreEffect.resetTransformationView(child);
        } else {
            resetView(child);
        }
    }

    protected void resetView(View child) {
        child.setPivotX(0f);
        child.setPivotY(0f);
        child.setTranslationX(0);
        child.setTranslationY(0);
        child.setScaleX(1f);
        child.setScaleY(1f);
        child.setRotation(0f);
        child.setRotationX(0f);
        child.setRotationY(0f);
        child.setAlpha(1f);
    }
    protected void resetTransformationGroup(ViewGroup group) {
        for (int i = group.getChildCount() - 1; i >= 0; i--) {
            resetTransformationView(group.getChildAt(i));
        }
    }
}