package com.example.martinrgb.myapplication.transitioneffects;

import java.util.ArrayList;


import android.content.Context;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;

public class TransitionEffectSwitcher extends TransitionEffect {

    public static final float DEFAULT_CAMERA_DISTANCE;
    public static float DEFAULT_ROTATE_CAMERA_DISTANCE ;
    static {
        final DisplayMetrics dm = Resources.getSystem().getDisplayMetrics();
        DEFAULT_CAMERA_DISTANCE = dm.density * 1280;
        DEFAULT_ROTATE_CAMERA_DISTANCE = (float) (Math.pow(2, dm.density) * dm.widthPixels / dm.density / 320.f * 1280);
    }
    public static final int SCREEN_TRANSITION_TYPE_CLASSIC = 0;
    public static final int SCREEN_TRANSITION_TYPE_CLASSIC_NO_OVER_SHOOT = 1;
    public static final int SCREEN_TRANSITION_TYPE_CROSSFADE = 2;
    public static final int SCREEN_TRANSITION_TYPE_FALLDOWN = 3;
    public static final int SCREEN_TRANSITION_TYPE_CUBE = 4;
    public static final int SCREEN_TRANSITION_TYPE_LEFTPAGE = 5;
    public static final int SCREEN_TRANSITION_TYPE_RIGHTPAGE = 6;
    public static final int SCREEN_TRANSITION_TYPE_STACK = 7;
    public static final int SCREEN_TRANSITION_TYPE_ROTATE = 8;
    public static final int SCREEN_TRANSITION_TYPE_COMMON = 8;

    public static final int TRANSITION_TYPE_EDITING_MODE = 9;
    public static final int TRANSITION_TYPE_NONE = 10;
    private static final int TRANSITION_TYPE_LAST = 11;

    private TransitionEffect mEffects[] =
            new TransitionEffect[TRANSITION_TYPE_LAST];
    private int mCurrentTypeIndex;
    private ArrayList<Integer> mCurrentTypeIndexList = new ArrayList<Integer>();
    public static final int mEffectsDrawableIds[] =
            new int[SCREEN_TRANSITION_TYPE_COMMON + 1];

    static {
        mEffectsDrawableIds[SCREEN_TRANSITION_TYPE_CLASSIC] = R.drawable.transition_effect_classic;
        mEffectsDrawableIds[SCREEN_TRANSITION_TYPE_CLASSIC_NO_OVER_SHOOT] =
                R.drawable.transition_effect_classic_no_over_shoot;
        mEffectsDrawableIds[SCREEN_TRANSITION_TYPE_CROSSFADE] =
                R.drawable.transition_effect_fade_out;
        mEffectsDrawableIds[SCREEN_TRANSITION_TYPE_FALLDOWN] =
                R.drawable.transition_effect_fall_down;
        mEffectsDrawableIds[SCREEN_TRANSITION_TYPE_CUBE] =
                R.drawable.transition_effect_cube;
        mEffectsDrawableIds[SCREEN_TRANSITION_TYPE_LEFTPAGE] =
                R.drawable.transition_effect_left_page;
        mEffectsDrawableIds[SCREEN_TRANSITION_TYPE_RIGHTPAGE] = -1;
        mEffectsDrawableIds[SCREEN_TRANSITION_TYPE_STACK] =
                R.drawable.transition_effect_stack;
        mEffectsDrawableIds[SCREEN_TRANSITION_TYPE_ROTATE] =
                R.drawable.transition_effect_rotate;
    }

    public TransitionEffectSwitcher() {}

    public final boolean isValidType() {
        return mCurrentTypeIndex >= 0 && mCurrentTypeIndex < TRANSITION_TYPE_LAST;
    }

    public int setTransitionType(int type) {
        mCurrentTypeIndex = type;
        mCurrentTypeIndexList.clear();
        mCurrentTypeIndexList.add(Integer.valueOf(mCurrentTypeIndex));
        addTransitionType(type, null);
        return getTransitionType();
    }

    private void addTransitionType(int type, TransitionEffect lastEffect) {
        if (isValidType() && mEffects[mCurrentTypeIndex] == null) {
            mEffects[mCurrentTypeIndex] = createEffect(type);
        }
        mEffects[mCurrentTypeIndex].mPreEffect = lastEffect;
    }
    public void appendTransitionType(int type) {
        mCurrentTypeIndex = type;
        TransitionEffect last = null;
        if (mCurrentTypeIndexList.size() > 0) {
            int lastTypeIndex = mCurrentTypeIndexList.get(mCurrentTypeIndexList.size() - 1);
            last = mEffects[lastTypeIndex];
        }
        addTransitionType(type, last);
        mCurrentTypeIndexList.add(Integer.valueOf(type));
    }

    public boolean removeTransitionType(int type) {
        if (type < 0 || type >= TRANSITION_TYPE_LAST
                || mEffects[type] == null) {
            return false;
        }
        mCurrentTypeIndex = type;
        mEffects[mCurrentTypeIndex].mPreEffect = null;
        boolean removed = mCurrentTypeIndexList.remove(Integer.valueOf(type));
        int size = mCurrentTypeIndexList.size();
        if (size > 0) {
            mCurrentTypeIndex = mCurrentTypeIndexList.get(size - 1);
        }
        return removed;
    }

    public int getTransitionType() {
        return mCurrentTypeIndex;
    }

    private TransitionEffect createEffect(int type) {
        switch(type) {
        case SCREEN_TRANSITION_TYPE_CLASSIC:
            return new TransitionEffectClassic();
        case SCREEN_TRANSITION_TYPE_CLASSIC_NO_OVER_SHOOT:
            return new TransitionEffectClassicNoOverShoot();
        case SCREEN_TRANSITION_TYPE_CROSSFADE:
            return new TransitionEffectCrossFade();
        case SCREEN_TRANSITION_TYPE_FALLDOWN:
            return new TransitionEffectFallDown();
        case SCREEN_TRANSITION_TYPE_CUBE:
            return new TransitionEffectCube();
        case SCREEN_TRANSITION_TYPE_LEFTPAGE:
            return new TransitionEffectLeftPage();
        case SCREEN_TRANSITION_TYPE_RIGHTPAGE:
            return new TransitionEffectRightPage();
        case SCREEN_TRANSITION_TYPE_STACK:
            return new TransitionEffectStack();
        case SCREEN_TRANSITION_TYPE_ROTATE:
            return new TransitionEffectRotate();

        case TRANSITION_TYPE_NONE:
            return new TransitionEffectNoType();
        case TRANSITION_TYPE_EDITING_MODE:
            return new TransitionEffectEditingMode();
        }
        return null;
    }

    @Override
    public void updateTransformation(float interpolation, float deltaX,
            float touchX, float touchY, View child, ViewGroup group) {
        if (isValidType()) {
            for (Integer i : mCurrentTypeIndexList) {
                mEffects[i].updateTransformation(
                        interpolation, deltaX, touchX, touchY, child, group);
            }
        }
    }

    @Override
    public float getOverShotTension() {
        if (isValidType()) {
            return mEffects[mCurrentTypeIndex].getOverShotTension();
        }
        return 0;
    }

    @Override
    public int getScreenSnapDuration() {
        if (isValidType()) {
            return mEffects[mCurrentTypeIndex].getScreenSnapDuration();
        }
        return 0;
    }

    @Override
    public void resetTransformation(View child, ViewGroup group) {
        if (isValidType()) {
            mEffects[mCurrentTypeIndex].resetTransformation(child, group);
        }
    }

    public void onScreenOrientationChanged(Context context) {
        final DisplayMetrics dm = context.getResources().getDisplayMetrics();
        DEFAULT_ROTATE_CAMERA_DISTANCE = (float) (Math.pow(2, dm.density) * dm.widthPixels / dm.density / 320.f * 1280);
    }
}