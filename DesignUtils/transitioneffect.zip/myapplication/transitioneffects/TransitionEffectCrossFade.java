package com.example.martinrgb.myapplication.transitioneffects;

import android.view.View;
import android.view.ViewGroup;

public class TransitionEffectCrossFade extends TransitionEffect {

    @Override
    public void updateTransformation(float interpolation, float deltaX,
            float touchX, float touchY, View child, ViewGroup group) {
        if (Math.abs(interpolation) > 1.f) {
            resetTransformationView(child);
            return;
        }
        if (mPreEffect == null) {
            resetView(child);
        }
        child.setAlpha((1 - Math.abs(interpolation)) * .7f + .3f);
    }

    @Override
    public float getOverShotTension() {
        return 0;
    }

    @Override
    public int getScreenSnapDuration() {
        return (int) (DEFAULT_SCREEN_SNAP_DURATION * .9f);
    }

    @Override
    public void resetTransformation(View child, ViewGroup group) {
        super.resetTransformationView(child);
    }

}
