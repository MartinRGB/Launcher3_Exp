package com.example.martinrgb.myapplication.transitioneffects;

import android.view.View;
import android.view.ViewGroup;

public class TransitionEffectCube extends TransitionEffect {

    @Override
    public void updateTransformation(float interpolation, float deltaX,
            float touchX, float touchY, View child, ViewGroup group) {
        if(interpolation == 0 || Math.abs(interpolation) > 1.f) {
            child.setLayerType(View.LAYER_TYPE_NONE, null);
            resetTransformationView(child);
            return;
        }
        if (mPreEffect == null) {
            resetView(child);
        }

        if (child.getLayerType() != View.LAYER_TYPE_HARDWARE) {
            child.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        }

        final float childW = child.getMeasuredWidth();
        final float childH = child.getMeasuredHeight();
        final float halfChildH = childH / 2.0f;

        float scaleY = child.getScaleY();
        float transY = child.getTranslationY();
        float pivotY = child.getPivotY();

        child.setAlpha((1.f));
        transY += (pivotY - halfChildH) * (1 - scaleY);
        child.setTranslationY(transY);
        child.setPivotX(interpolation < 0 ? 0 : childW);
        child.setPivotY(halfChildH);
        child.setRotation(0.f);
        child.setRotationX(0.f);
        child.setRotationY(-90.0f * interpolation);
        child.setCameraDistance(TransitionEffectSwitcher.DEFAULT_ROTATE_CAMERA_DISTANCE);
    }

    @Override
    public float getOverShotTension() {
        return 0;
    }

    @Override
    public int getScreenSnapDuration() {
        return (int) (DEFAULT_SCREEN_SNAP_DURATION * 1.1f);
    }

    @Override
    public void resetTransformation(View child, ViewGroup group) {
        super.resetTransformationView(child);
    }

}
