package com.example.martinrgb.myapplication.transitioneffects;

import android.view.View;
import android.view.ViewGroup;

public class TransitionEffectFallDown extends TransitionEffect {

    @Override
    public void updateTransformation(float interpolation, float deltaX,
            float touchX, float touchY, View child, ViewGroup group) {
        if (interpolation == 0 || Math.abs(interpolation) > 1.f) {
            child.setLayerType(View.LAYER_TYPE_NONE, null);
            resetTransformationView(child);
            return;
        }

        if (mPreEffect == null) {
            resetView(child);
        }

        if (child.getLayerType() != View.LAYER_TYPE_HARDWARE) {
            child.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        }

        final float childW = child.getMeasuredWidth();
        final float childH = child.getMeasuredHeight();
        final float halfChildW = childW / 2.0f;

        float scaleY = child.getScaleY();
        float scaleX = child.getScaleX();
        float transX = child.getTranslationX();
        float pivotX = child.getPivotX();
        float transY = child.getTranslationY();
        float pivotY = child.getPivotY();
        child.setAlpha(1.f);
        transX += (pivotX - halfChildW) * (1 - scaleX);
        transY += (pivotY - childH) * (1 - scaleY);
        child.setTranslationX(transX);
        child.setTranslationY(transY);
        child.setPivotX(halfChildW);
        child.setPivotY(childH);
        child.setRotation(-interpolation * 30);
        child.setRotationX(0.f);
        child.setRotationY(0.f);
        child.setCameraDistance(TransitionEffectSwitcher.DEFAULT_CAMERA_DISTANCE);
    }

    @Override
    public float getOverShotTension() {
        return DEFAULT_OVER_SHOOT_TENSION;
    }

    @Override
    public int getScreenSnapDuration() {
        return DEFAULT_SCREEN_SNAP_DURATION;
    }

    @Override
    public void resetTransformation(View child, ViewGroup group) {
        super.resetTransformationView(child);
    }
}
