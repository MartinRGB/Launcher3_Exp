package com.example.martinrgb.myapplication.transitioneffects;

import android.view.View;
import android.view.ViewGroup;

public class TransitionEffectLeftPage extends TransitionEffect {

    @Override
    public void updateTransformation(float interpolation, float deltaX,
            float touchX, float touchY, View child, ViewGroup group) {
        if(interpolation == 0 || Math.abs(interpolation) > 1.f) {
            resetTransformationView(child);
            return;
        }
        if (mPreEffect == null) {
            resetView(child);
        }
        final float childW = child.getMeasuredWidth();
        final float childH = child.getMeasuredHeight();
        final float halfChildW = childW / 2.0f;
        final float halfChildH = childH / 2.0f;

        float scaleY = child.getScaleY();
        float scaleX = child.getScaleX();
        float transY = child.getTranslationY();
        float pivotY = child.getPivotY();

        child.setAlpha((1 - Math.abs(interpolation)));
        transY += (pivotY - halfChildH) * (1 - scaleY);
        child.setTranslationY(transY);
        child.setTranslationX((childW * interpolation - childW * Math.abs(interpolation) * .3f) * scaleX);
        final float scale1 = 1.f + .3f * interpolation;
        child.setScaleX(scale1 * scaleX);
        child.setScaleY(scale1 * scaleY);
        child.setPivotX(halfChildW);
        child.setPivotY(halfChildH);
        child.setRotation(0.f);
        child.setRotationX(0.f);
        child.setRotationY(45.0f * -interpolation);
        child.setCameraDistance(TransitionEffectSwitcher.DEFAULT_ROTATE_CAMERA_DISTANCE);
    }

    @Override
    public float getOverShotTension() {
        return 0;
    }

    @Override
    public int getScreenSnapDuration() {
        return (int) (DEFAULT_SCREEN_SNAP_DURATION * 1.1f);
    }

    @Override
    public void resetTransformation(View child, ViewGroup group) {
        super.resetTransformationView(child);
    }
}
