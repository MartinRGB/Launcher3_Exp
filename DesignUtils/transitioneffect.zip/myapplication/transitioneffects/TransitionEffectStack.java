package com.example.martinrgb.myapplication.transitioneffects;

import android.view.View;
import android.view.ViewGroup;

public class TransitionEffectStack extends TransitionEffect {

    @Override
    public void updateTransformation(float interpolation, float deltaX,
            float touchX, float touchY, View child, ViewGroup group) {
        if(interpolation <= 0.f || interpolation >= 1.f) {
            resetTransformationView(child);
            return;
        }
        if (mPreEffect == null) {
            resetView(child);
        }
        final float childW = child.getMeasuredWidth();
        final float childH = child.getMeasuredHeight();
        final float halfChildH = childH / 2.0f;

        float scaleY = child.getScaleY();
        float scaleX = child.getScaleX();
        float transY = child.getTranslationY();
        float pivotY = child.getPivotY();
        child.setAlpha(1 - interpolation);
        final float scale2 = 0.6f + 0.4f * (1 - interpolation);
        transY += (pivotY - halfChildH) * (1 - scaleY);
        child.setTranslationY(transY);
        float transXDelta = childW * (1 - scaleX) / 2.f;
        child.setTranslationX(childW * (1 - scale2) * 3.0f + transXDelta);
        child.setScaleX(scale2 * scaleX);
        child.setScaleY(scale2 * scaleY);
        child.setPivotX(0.f);
        child.setPivotY(halfChildH);
        child.setRotation(0.f);
        child.setRotationX(0.f);
        child.setRotationY(0.f);
        child.setCameraDistance(TransitionEffectSwitcher.DEFAULT_CAMERA_DISTANCE);
    }

    @Override
    public float getOverShotTension() {
        return 0;
    }

    @Override
    public int getScreenSnapDuration() {
        return (int) (DEFAULT_SCREEN_SNAP_DURATION * .9f);
    }

    @Override
    public void resetTransformation(View child, ViewGroup group) {
        super.resetTransformationView(child);
    }

}
