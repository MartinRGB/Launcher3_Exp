package com.example.martinrgb.myapplication.transitioneffects;

import android.view.View;
import android.view.ViewGroup;

public class TransitionEffectEditingMode extends TransitionEffect {

    public static final float SCREEN_SCALE_RATO = 0.92f;
    public static final float SCREEN_TRANS_V_RATO =  -0.025f;
    static final public float SCREEN_VISIBLE_RATO = 2 -SCREEN_SCALE_RATO;
    static final float SCREEN_TRANS_H_RATO = (1 - SCREEN_SCALE_RATO) / 2.f;

    public TransitionEffectEditingMode() {
    }

    @Override
    public void updateTransformation(float interpolation,
            float deltaX, float touchX, float touchY, View child, ViewGroup group) {
        if (Math.abs(interpolation) > SCREEN_VISIBLE_RATO) {
            resetTransformationView(child);
            return;
        }
        if (mPreEffect == null) {
            resetView(child);
        }
        final float childW = child.getMeasuredWidth();
        final float childH = child.getMeasuredHeight();
        final float transH = childW * SCREEN_TRANS_H_RATO;
        final float transOffset = 2 * transH * interpolation;
        final float transV = childH * SCREEN_TRANS_V_RATO;
        child.setAlpha(1.f);
        child.setTranslationX(interpolation > 0 ? transOffset - transH : transOffset + transH);
        child.setTranslationY(transV);
        child.setScaleX(SCREEN_SCALE_RATO);
        child.setScaleY(SCREEN_SCALE_RATO);
        child.setPivotX(interpolation > 0.f ?childW : 0);
        child.setPivotY(childH / 2.f);
        child.setRotation(0.f);
        child.setRotationX(0.f);
        child.setRotationY(0.f);
        child.setCameraDistance(TransitionEffectSwitcher.DEFAULT_CAMERA_DISTANCE);
    }

    @Override
    public float getOverShotTension() {
        return 0.f;
    }

    @Override
    public int getScreenSnapDuration() {
        return 180;
    }

    @Override
    protected void resetView(View child) {
        final float childW = child.getMeasuredWidth();
        final float childH = child.getMeasuredHeight();
        final float transV = childH * SCREEN_TRANS_V_RATO;
        child.setTranslationY(transV);
        child.setTranslationX(0.f);
        final float halfChildW = childW / 2.0f;
        final float halfChildH = childH / 2.0f;
        child.setPivotX(halfChildW);
        child.setPivotY(halfChildH);
        child.setScaleX(SCREEN_SCALE_RATO);
        child.setScaleY(SCREEN_SCALE_RATO);
        child.setRotationX(0.f);
        child.setRotationY(0.f);
        child.setCameraDistance(TransitionEffectSwitcher.DEFAULT_CAMERA_DISTANCE);
    }
    @Override
    public void resetTransformation(View child, ViewGroup group) {
        resetTransformationView(child);
    }
}