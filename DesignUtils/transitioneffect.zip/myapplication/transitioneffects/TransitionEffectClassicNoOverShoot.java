package com.example.martinrgb.myapplication.transitioneffects;

import android.view.View;
import android.view.ViewGroup;

public class TransitionEffectClassicNoOverShoot extends TransitionEffect {

    @Override
    public void updateTransformation(float interpolation, float deltaX,
            float touchX, float touchY, View child, ViewGroup group) {
        if (mPreEffect == null) {
            resetView(child);
        }
    }

    @Override
    public float getOverShotTension() {
        return 0;
    }

    @Override
    public int getScreenSnapDuration() {
        return (int) (DEFAULT_SCREEN_SNAP_DURATION);
    }

    @Override
    public void resetTransformation(View child, ViewGroup group) {
        super.resetTransformationView(child);
    }

}
